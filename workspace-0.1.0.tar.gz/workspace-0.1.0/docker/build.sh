if [[ $1 == "30" ]]; then
  dockerfile="gpu30.Dockerfile"
  imagename="tower.featurize.cn/featurize-gpu-30:latest"
else
  dockerfile="gpu.Dockerfile"
  imagename="tower.featurize.cn/featurize-gpu:latest"
fi
docker build --network host -f $dockerfile -t $imagename .

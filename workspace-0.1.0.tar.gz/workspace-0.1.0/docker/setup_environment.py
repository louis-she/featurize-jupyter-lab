# import os
# import json
#
# user_cfg_file = '/home/featurize/work/.user_cfg.json'
#
# try:
#     with open(user_cfg_file, 'r') as f:
#         cfg = json.load(f)
# except Exception:
#     cfg = {}
#
# environment = cfg.get('environment', 'default')
#
# os.system(f'echo "export PYTHONPATH=/home/featurize/work/.local/lib/python3.7/site-packages:/environment/python/{environment}/lib/python3.7/site-packages" >> /home/featurize/.zshrc')
#
# os.unlink('/environment/python/versions/3.7.4/share/jupyter/kernels/python3/kernel.json')
# os.link(
#     f'/environment/python/versions/3.7.4/share/jupyter/kernels/python3/{environment}.kernel.json',
#     '/environment/python/versions/3.7.4/share/jupyter/kernels/python3/kernel.json'
# )
#
#
# if environment == 'tensorflow-1.15':
#     os.system('sudo rm /usr/local/cuda')
#     os.system('sudo ln -s /usr/local/cuda-10.0 /usr/local/cuda')
# else:
#     os.system('sudo rm /usr/local/cuda')
#     os.system('sudo ln -s /usr/local/cuda-10.1 /usr/local/cuda')


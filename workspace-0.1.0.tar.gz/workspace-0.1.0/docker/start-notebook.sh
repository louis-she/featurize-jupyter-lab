#!/bin/bash

if [ ! -L /home/featurize/work ]; then
  ln -sf /cloud /home/featurize/work
fi

nohup /usr/bin/agent &

sudo usermod --password $(echo $SSH_PWD | openssl passwd -1 -stdin) featurize
unset SSH_PWD

sudo /etc/init.d/ssh restart

if test -f "/home/featurize/work/.onboot.sh"; then
  /home/featurize/work/.onboot.sh &
fi

/environment/python/versions/3.7.4/bin/python -m workspace.server \
  --KernelSpecManager.ensure_native_kernel=False \
  --no-browser \
  --ServerApp.base_url=$UUID \
  --port=8877 \
  --FeaturizeNotebookApp.user_settings_dir=/home/featurize/work/.jupyter/user_setting \
  --ServerApp.login_handler_class=workspace.FeaturizeLoginHandler \
  --ServerApp.logout_handler_class=workspace.FeaturizeLogoutHandler

import asyncio
import time
from types import coroutine
from typing import Coroutine
import websockets
from websockets.client import ClientConnection
from websockets.uri import parse_uri

async def test():
    print("hi")
    return 1

res = test()
if asyncio.iscoroutine(res):
    asyncio.run(res)

# ws = ClientConnection(parse_uri("ws://dev.featurize.ai:8000/bus/agent/channel?token=5f1478eb598b438abf7b05906af4fa4c"))
# res = ws.send_request(ws.connect())
# print(res)
# while True:
#     time.sleep(3)
#     ws.send_text("{}")

# async def hello():
#     ws = await websockets.connect("ws://dev.featurize.ai:8000/bus/agent/channel?token=5f1478eb598b438abf7b05906af4fa4c")
#     while True:
#         await asyncio.sleep(1)
#         await ws.send("{}")
#
# asyncio.run(hello())


# import threading
# from websocket import create_connection, WebSocketApp
# import websocket
# import time

# # ws = create_connection("ws://dev.featurize.ai:8000/bus/agent/channel?token=5f1478eb598b438abf7b05906af4fa4c")

# # event = threading.Event()
# # thread = threading.Thread(
# #     target=self._send_ping, args=(ping_interval, event, ping_payload))
# # thread.daemon = True
# # thread.start()
# # while True:
# #     time.sleep(1)
# #     ws.send("{}")

# def on_open(ws):
#     print("opend!!!")
#     while True:
#         time.sleep(1)
#         ws.send("{}")

# websocket.enableTrace(True)
# ws = WebSocketApp(url="ws://dev.featurize.ai:8000/bus/agent/channel?token=5f1478eb598b438abf7b05906af4fa4c", on_open=on_open)
# ws.run_forever(ping_interval=10)

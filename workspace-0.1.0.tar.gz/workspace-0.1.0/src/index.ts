import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin,
} from '@jupyterlab/application';
// @ts-ignore
import ReactDOM from "react-dom"
import { ILauncher } from '@jupyterlab/launcher'
import { IStatusBar } from '@jupyterlab/statusbar'
import { IFileBrowserFactory } from '@jupyterlab/filebrowser';
import { BottomStatus } from "./bottom-status"
import { init } from './storage';
import { TopToolbar } from './top-toolbar';
import { Clipboard, showDialog } from '@jupyterlab/apputils';
import { PageConfig } from '@jupyterlab/coreutils';
import DatasetDialog from './dataset-dialog';
import React from 'react';
import SshDialog from './ssh-dialog';
import IdeDialog from './ide-dialog';
import AskDialog from './ask-dialog';
import moment from 'moment';
import { alertDialog, requestLab } from './helper';

const extension: JupyterFrontEndPlugin<void> = {
  id: 'react-widget',
  autoStart: true,
  // @ts-ignore
  requires: [IStatusBar, ILauncher, IFileBrowserFactory, ],
  activate: (app: JupyterFrontEnd, statusBar: IStatusBar, launcher: ILauncher, factory: IFileBrowserFactory) => {
    moment.updateLocale('en', {
      relativeTime : {
        future: "%s后",
        past:   "%s前",
        s: "不久",
        m: "一分钟",
        mm: "%d分钟",
        h:  "一小时",
        hh: "%d小时",
        d:  "一天",
        dd: "%d天",
        M:  "一个月",
        MM: "%d个月",
        y:  "一年",
        yy: "%d年"
      },
      // @ts-ignore
      longDateFormat: {
        L: 'YYYY-MM-DD',
        LT: 'HH:mm',
      },
      meridiem : function (hour, minute) {
        let hm = hour * 100 + minute;
        if (hm < 600) {
          return '凌晨'
        } else if (hm < 900) {
          return '早上'
        } else if (hm < 1130) {
          return '上午'
        } else if (hm < 1230) {
          return '中午'
        } else if (hm < 1800) {
          return '下午'
        } else {
          return '晚上'
        }
    }})

    init(() => {
      // 添加全局弹窗的容器
      const globalDiv = document.createElement("div")
      globalDiv.id = "__global_root__"
      document.body.insertAdjacentElement("beforeend", globalDiv)

      // 底部状态栏
      statusBar.registerStatusItem('featurize-bottom-status', {
        align: 'middle',
        item: new BottomStatus(app)
      })

      // 顶部的 ToolBar
      const topToolbar = new TopToolbar(app)
      topToolbar.id = 'featurize-top-toolbar'
      app.shell.add(topToolbar, 'top', { rank: 1000 })

      // 数据集 launcher
      const datasetLauncher : ILauncher.IItemOptions = {
        command: 'featurize:dataset',
        rank: 1,
        category: 'Featurize',
      }
      launcher.add(datasetLauncher)

      app.commands.addCommand("featurize:dataset", {
        label: '添加数据集',
        iconClass: 'featurize__dataset',
        execute: () => {
          ReactDOM.render(
            React.createElement(DatasetDialog, {
              onHide: () => {
                ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__'))
              }
            }),
            document.getElementById('__global_root__')
          )
        },
      })

      // 添加 ssh launcher
      const sshLauncher : ILauncher.IItemOptions = {
        command: 'featurize:ssh',
        rank: 2,
        category: 'Featurize',
      }
      launcher.add(sshLauncher)

      app.commands.addCommand("featurize:ssh", {
        label: 'SSH 连接',
        iconClass: 'featurize__ssh',
        execute: () => {
          ReactDOM.render(
            React.createElement(SshDialog, {
              onHide: () => {
                ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__'))
              }
            }),
            document.getElementById('__global_root__')
          )
        },
      })

      // IDE 远程调试
      const ideLauncher : ILauncher.IItemOptions = {
        command: 'featurize:ide',
        rank: 3,
        category: 'Featurize',
      }
      launcher.add(ideLauncher)

      app.commands.addCommand("featurize:ide", {
        label: 'IDE 远程调试',
        iconClass: 'featurize__ide',
        execute: () => {
          ReactDOM.render(
            React.createElement(IdeDialog, {
              onHide: () => {
                ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__'))
              }
            }),
            document.getElementById('__global_root__')
          )
        },
      })

      // IDE 远程调试
      const askLauncher : ILauncher.IItemOptions = {
        command: 'featurize:ask',
        rank: 4,
        category: 'Featurize',
      }
      launcher.add(askLauncher)

      app.commands.addCommand("featurize:ask", {
        label: '向喵创提问',
        iconClass: 'featurize__ask',
        execute: () => {
          ReactDOM.render(
            React.createElement(AskDialog, {
              onHide: () => {
                ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__'))
              }
            }),
            document.getElementById('__global_root__')
          )
        },
      })

      app.commands.addKeyBinding({
        command: "featurize:ask",
        args: {},
        keys: ['Accel Shift M'],
        selector: 'body'
      });

      const { tracker, defaultBrowser } = factory

      app.commands.addCommand("filebrowser:destroy_folder", {
        execute: async () => {
          let res = await showDialog({
            title: "删除确认",
            body: "是否真的要删除这些文件，该操作不可恢复！",
          })
          if (res.button.label !== "OK") return;
          const widget = tracker.currentWidget
          const items = widget.selectedItems()
          const files = []
          while (true) {
            let file = items.next()
            if (!file) {
              break
            }
            files.push(file)
          }
          await requestLab({
            path: '/featurize/remove_folder_files',
            method: 'post',
            data: {
              files: files,
              path: defaultBrowser.model.path
            }
          })
          await defaultBrowser.model.refresh()
        },
        iconClass: 'jp-MaterialIcon jp-CloseIcon',
        label: '彻底删除文件或目录'
      })

      app.commands.addCommand("filebrowser:copy_abs_path", {
        execute: () => {
          const widget = tracker.currentWidget
          const item = widget?.selectedItems().next();
          if (!item) {
            return;
          }
          Clipboard.copyToSystem(`${PageConfig.getOption('serverRoot')}/${item.path}`);
        },
        iconClass: 'jp-MaterialIcon jp-FileIcon',
        label: '复制绝对路径'
      })

      // 压缩
      app.commands.addCommand("filebrowser:compress_files", {
        execute: () => {
          const widget = tracker.currentWidget
          const items = widget.selectedItems()
          const files = []
          while (true) {
            let file = items.next()
            if (!file) {
              break
            }
            files.push(file)
          }

          (async function() {
            await requestLab({
              path: '/featurize/compress',
              method: 'post',
              data: {
                files: files,
                path: defaultBrowser.model.path
              }
            })
            await defaultBrowser.model.refresh()
          }());
        },
        iconClass: 'jp-MaterialIcon jp-FileIcon',
        label: '压缩多个文件'
      })

      // 解压缩
      app.commands.addCommand("filebrowser:uncompress_file", {
        execute: () => {
          const widget = tracker.currentWidget
          const items = widget.selectedItems()
          const files = []
          while (true) {
            let file = items.next()
            if (!file) {
              break
            }
            files.push(file)
          }

          if (files.length > 1) {
            return alertDialog({
              level: "warning",
              content: "请选择单个文件解压",
            })
          }

          const file = files[0]
          if (!(['zip', 'tar.gz', 'gz', 'tar'].includes(file.name.split(".").reverse()[0]))) {
            return alertDialog({
              level: "warning",
              content: "请选择正确的压缩文件，文件格式为 zip 或 tar.gz",
            })
          }

          (async function() {
            await requestLab({
              path: '/featurize/uncompress',
              method: 'post',
              data: {
                file: file,
                path: defaultBrowser.model.path
              }
            })
            await defaultBrowser.model.refresh()
          }());
        },
        iconClass: 'jp-MaterialIcon jp-FileIcon',
        label: '解压文件'
      })

      app.contextMenu.addItem({
        command: "filebrowser:destroy_folder",
        selector: ".jp-DirListing-item",
        rank: 1
      });

      app.contextMenu.addItem({
        command: "filebrowser:copy_abs_path",
        selector: ".jp-DirListing-item",
        rank: 2
      });

      app.contextMenu.addItem({
        command: "filebrowser:compress_files",
        selector: ".jp-DirListing-item",
        rank: 3
      });

      app.contextMenu.addItem({
        command: "filebrowser:uncompress_file",
        selector: '[data-file-type="text"]',
        rank: 4
      });
    })
  },
}

export default extension

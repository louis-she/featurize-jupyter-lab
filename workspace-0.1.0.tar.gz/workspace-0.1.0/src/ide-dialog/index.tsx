import clsx from "clsx"
import React, { useState, useEffect, useMemo, useRef } from "react"
import Dialog from "../components/dialog"
import style from "./index.module.scss"
import { Win10, Apple, Ubuntu, Vscode, Pycharm } from "../icons"
import hljs from 'highlight.js'
import 'highlight.js/styles/github.css';
import CopyItem from "../components/copy-item"
import { storage } from "../storage"

const Img = ({ src }: { src : string }) => {
  return (
    <div className={style.imgWrapper}>
      <img src={src} />
    </div>
  )
}

const IdeDialog = ({ onHide } : {onHide: any}) => {

  const [operatingSystem, setOperatingSystem] = useState("Windows 10")
  const [ide, setIde] = useState("Visual Studio Code")
  const contentRef = useRef<any>()

  useEffect(() => {
    contentRef.current.scrollTo(0, 0)
  }, [ide, operatingSystem])

  const ctrl = useMemo(() => {
    if (operatingSystem === "Windows 11" || operatingSystem === "Ubuntu") {
      return "ctrl"
    } else {
      return "command"
    }
  }, [operatingSystem])

  useEffect(() => {
    hljs.highlightAll()
  }, [operatingSystem, ide])

  const renderVscodeInstallExtension = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 在 Code 中安装 Remote - SSH 插件
      </div>
      <div className={style.stepDesc}>
        <p>点击 Visual Studio Code 左侧的插件管理器，然后搜索 ssh，安装第一个插件 Remote - SSH 即可。</p>
        <p>注意：此步骤无需重复操作，仅未安装该插件的用户需要执行，下次连接时可跳过该步骤。</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-1-1.png" />
      </div>
    </div>

  const renderVscodeConnect = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 连接到实例
      </div>
      <div className={style.stepDesc}>
        <p>在 Visual Studio Code 中按 <b>{ctrl} + shift + p</b> 唤出命令界面，在输入框中中输入 <b>connect to host</b>，然后选择第一项。</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-2-1.png" />
        <p>然后会弹出一个新的输入框，将下面的文本复制粘贴到输入框中并按回车，注意，针对不同的实例该命令是<strong>不一样</strong>的。</p>
        <pre>
          <code className="language-plaintext">
            featurize@workspace.featurize.cn:{storage.vm.sshPort}
          </code>
        </pre>
        <p>现在 Visual Studio Code 会尝试连接实例，下方会有连接日志，若日志出现以下提示，则需要手动输入密码：</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-2-2.png" />
        <p>输入以下密码，注意，不同实例的密码依然是不同的，并且这里输入密码是没有显示上的反馈的：</p>
        <pre>
          <code className="language-plaintext">
            {storage.vm.featurizePassword}
          </code>
        </pre>
        <p>输入密码并回车后，如果终端中出现类似如下信息，则表示当前的 Visual Studio Code 已经成功连上实例：</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-2-3.png" />
        <p>请不要关闭当前终端，否则连接会断开，现在可以打开一个新的终端（zsh），应该会弹出 Featurize 的欢迎信息：</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-2-4.png" />
      </div>
    </div>

  const renderVscodeSelectWorkdir = (step: string) =>
  <div className={style.step}>
    <div className={style.stepHeader}>
      {step}. 打开工作目录
    </div>
    <div className={style.stepDesc}>
      <p>连接上实例后，你需要选择在哪个目录下工作，一般来说，选择你的项目的目录即可，项目应该是预先上传或通过 git 下载到实例上的某个代码目录，点击左侧的按钮，选择目录即可：</p>
      <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-3-1.png" />
      <p>选择过后，Visual Studio Code 会断开当前连接并重新连接实例，你需要再次输入密码</p>
    </div>
  </div>

  const renderInstallPythonExtension = (step: string) =>
  <div className={style.step}>
    <div className={style.stepHeader}>
      {step}. 安装 Python 插件
    </div>
    <div className={style.stepDesc}>
      <p>与之前安装 Remote - SSH 插件的方法一致，只是这次你需要搜索的关键字是 Python，在弹出中选择第一个插件并安装即可。</p>
      <p>如果你之前已经安装过此插件，依然不能忽略该步骤，因为此插件需要被安装在实例上，而不是客户端中。因此，当你切换实例之后，也需要重新执行该步骤，因为新的实例上也需要安装此插件。</p>
      <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-4-1.png" />
    </div>
  </div>

  const renderVscodeSelectInterpreter = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 选择正确的 Python 解释器
      </div>
      <div className={style.stepDesc}>
        <p>Featurize 的实例中内置了多个环境，在写代码之前，我们需要选择正确的环境来让一些功能工作（例如代码提示，Debug 等），而选择环境实际上就是选择与之对应的 Python 的解释器。</p>
        <p>按 <strong>{ctrl} + shift + p</strong> 呼出命令面板，在输入框中键入 <strong>python select interpreter</strong> 然后按回车。</p>
        <p>在新的弹出框中，会列出当前实例中已安装的 Python 解释器，选择你需要的解释器即可，平台默认的 base 环境解释器的路径为：</p>
        <pre>
          <code>
            /environment/miniconda3/bin/python
          </code>
        </pre>
        <p>注意：此步骤无需重复操作，仅未安装该插件的用户需要执行，下次连接时可跳过该步骤。</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-vscode-step-1-1.png" />
      </div>
    </div>

  const renderInstallOpenssh = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 安装 OpenSSH
      </div>
      <div className={style.stepDesc}>
        <p>Windows 10 系统需要首先安装 SSH 客户端才能进行连接：</p>
        <p>以管理员身份运行 PowerShell，你可以通过左下方的搜索框中直接搜索 PowerShell 即可，然后右键选择「已管理员身份运行」，在弹出的终端中依次输入并执行以下命令：</p>
        <pre>
          <code>
            Get-WindowsCapability -Online | ? Name -like 'OpenSSH*'
          </code>
        </pre>
        <pre>
          <code>
            Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
          </code>
        </pre>
      </div>
    </div>

  const renderPycharmSelectInterpreter = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 选择远程 Python 解释器
      </div>
      <div className={style.stepDesc}>
        <p>
          首先，使用 PyCharm 打开你希望调试的某个<strong>本地项目</strong>，打开后按 <strong>{ctrl} + ,</strong>， 唤出偏好设置。
          然后依次进入 <strong>Project: &lt;project name&gt;</strong> -&gt; <strong>Python Interpreter</strong>，
          点击右侧的 ⚙️ 按钮，选择 <strong>add</strong>。
        </p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-pycharm-step-1-1.png" />
        <p>在新弹出的窗口中，将下面的 SSH 信息填入，注意，不同实例的端口不同。</p>
        <CopyItem label="Host" value="workspace.featurize.cn" />
        <CopyItem label="Username" value="featurize" />
        <CopyItem label="Port" value={storage.vm.sshPort} />
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-pycharm-step-1-2.png" />
        <p>配置好后点击 <strong>next</strong>，然后提示输入密码，请将下方的密码填入，注意，不同实例的密码不同。</p>
        <CopyItem label="Password" value={storage.vm.featurizePassword} />
        <p>密码输入后点击 <strong>next</strong>，现在就已经连接到实例了，在下面的弹出框中，输入实例上你希望使用的环境的 Python 解释器。对于默认的 base 环境，解释器位于：</p>
        <pre>
          <code>
            /environment/miniconda3/bin/python
          </code>
        </pre>
        <p>另外，你还可以设置同步目录，默认为 <strong>/tmp/</strong> 下的一个随机目录，推荐将这个目录设置到 <strong>/home/featurize</strong> 中。配置完成后应如下图所示：</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-pycharm-step-1-3.png" />
        <p>点击 <strong>Finish</strong> 按钮，再点击 <strong>OK</strong> 则完成配置，此时 PyCharm 会将本地的项目文件全部上传至实例上的同步目录中，如果项目太大，可能需要等待较长时间。</p>
      </div>
    </div>

  const renderPycharmRunScript = (step: string) =>
    <div className={style.step}>
      <div className={style.stepHeader}>
        {step}. 运行程序
      </div>
      <div className={style.stepDesc}>
        <p>现在就可以开始使用 PyCharm 的运行或调试功能了：</p>
        <Img src="https://featurize-public.oss-cn-beijing.aliyuncs.com/workspace-pycharm-step-2-1.png" />
      </div>
    </div>

  return (
    <Dialog
      size="mega"
      footer={false}
      contentRef={contentRef}
      header={
        <div className={style.tabsGroup}>
          <div className={style.label}>
            操作系统：
          </div>
          <div className={style.tabs}>
            <div className={clsx(style.tab, {[style.active]: operatingSystem === "Windows 10"} )} onClick={() => setOperatingSystem("Windows 10")}>
              <Win10 />
              Windows 10
            </div>
            <div className={clsx(style.tab, {[style.active]: operatingSystem === "macOS"})} onClick={() => setOperatingSystem("macOS")}>
              <Apple />
              macOS
            </div>
            <div className={clsx(style.tab, {[style.active]: operatingSystem === "Ubuntu"})} onClick={() => setOperatingSystem("Ubuntu")}>
              <Ubuntu />
              Ubuntu
            </div>
          </div>
          <div className={style.label}>
            开发软件：
          </div>
          <div className={style.tabs}>
            <div className={clsx(style.tab, {[style.active]: ide === "Visual Studio Code"})} onClick={() => setIde("Visual Studio Code")}>
              <Vscode />
              Visual Studio Code
            </div>
            <div className={clsx(style.tab, {[style.active]: ide === "PyCharm"})} onClick={() => setIde("PyCharm")}>
              <Pycharm />
              PyCharm
            </div>
          </div>
        </div>
      }
      show
      onHide={onHide}
      onNo={onHide}
      icon={false}
    >
      <h5>在 {operatingSystem} 中使用 {ide} 远程调试</h5>
      {operatingSystem === "macOS" && ide === "PyCharm" &&
      <>
        <p>注意：PyCharm 免费版不提供远程运行/调试功能，请使用 PyCharm 付费版或教育版。</p>
        {renderPycharmSelectInterpreter("1")}
        {renderPycharmRunScript("2")}
      </>
      }

      {operatingSystem === "Ubuntu" && ide === "PyCharm" &&
      <>
        <p>注意：PyCharm 免费版不提供远程运行/调试功能，请使用 PyCharm 付费版或教育版。</p>
        {renderPycharmSelectInterpreter("1")}
        {renderPycharmRunScript("2")}
      </>
      }

      {operatingSystem === "Windows 10" && ide === "PyCharm" &&
      <>
        <p>注意：本文档只针对 Windows 10 操作系统，Windows 7 并不适用；PyCharm 免费版不提供远程运行/调试功能，请使用 PyCharm 付费版或教育版。</p>
        {renderInstallOpenssh("1")}
        {renderPycharmSelectInterpreter("2")}
        {renderPycharmRunScript("3")}
      </>
      }

      {operatingSystem === "macOS" && ide === "Visual Studio Code" &&
      <>
        {renderVscodeInstallExtension("1")}
        {renderVscodeConnect("2")}
        {renderVscodeSelectWorkdir("3")}
        {renderInstallPythonExtension("4")}
        {renderVscodeSelectInterpreter("5")}
      </>
      }
      {operatingSystem === "Ubuntu" && ide === "Visual Studio Code" &&
      <>
        {renderVscodeInstallExtension("1")}
        {renderVscodeConnect("2")}
        {renderVscodeSelectWorkdir("3")}
        {renderInstallPythonExtension("4")}
        {renderVscodeSelectInterpreter("5")}
      </>
      }
      {operatingSystem === "Windows 10" && ide === "Visual Studio Code" &&
      <>
        <p>注意：本文档只针对 Windows 10 操作系统，Windows 7 并不适用。</p>
        {renderInstallOpenssh("1")}
        {renderVscodeInstallExtension("2")}
        {renderVscodeConnect("3")}
        {renderVscodeSelectWorkdir("4")}
        {renderInstallPythonExtension("5")}
        {renderVscodeSelectInterpreter("6")}
      </>
      }
    </Dialog>
  )
}

export default IdeDialog

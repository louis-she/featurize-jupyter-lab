import clsx from 'clsx'
import React, { useState, useEffect } from 'react'
import style from './index.module.scss'

const PopupConfirm = ({
  children,
  onOK,
  onCancel,
  content,
  direction='top'
} : {
  content: string,
  children: React.ReactNode,
  onOK: any,
  onCancel?: any,
  direction?: string
}) => {

  const [pending, setPending] = useState(false)

  useEffect(() => {
    document.addEventListener("click", () => {setActive(false)})
  }, [])

  const [active, setActive] = useState<boolean>(false)

  const handleOKClicked = async () => {
    setPending(true)
    await onOK()
    setPending(false)
    setActive(false)
  }

  const handleCancelClicked = () => {
    setActive(false)
  }

  const handleChildClicked = () => {
    setActive(true)
  }

  const handleRootClicked = (e: React.MouseEvent) => {
    e.stopPropagation()
  }

  return (
    <div className={clsx(style.root, style[direction])} onClick={handleRootClicked}>
      {active &&
        <div className={style.pop}>
          {content}
          <div className={style.operations}>
            <a className={clsx({diabled: pending})} onClick={handleOKClicked}>确定</a>
            <a onClick={handleCancelClicked}>取消</a>
          </div>
        </div>
      }
      <div className={style.contentWrapper} onClick={handleChildClicked}>
        {children}
      </div>
    </div>
  )
}

export default PopupConfirm

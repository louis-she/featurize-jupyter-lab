import clsx from "clsx"
import React from "react"
import style from "./index.module.scss"

type IColumnConfig<T,> = {
  label: string
  noShrink: boolean
  width?: string
  align: string
  thClassName: string
  tdClassName: string
  renderer: (record: T) => any
  key: string
}

type IDataTable<T> = React.HTMLProps<HTMLDivElement>  & { records: any, columnsConfig: Partial<IColumnConfig<T>>[]}

const DataTable = <T,>({ records, columnsConfig, className, ...htmlProps} : IDataTable<T> ) => {
  return (
    <div className={clsx(style.root, className)} {...htmlProps}>
      <table>
        <thead>
          <tr className={style.headTr}>
            {columnsConfig.map((c, index) =>
              <th key={index} className={`${c.thClassName || ""} ${c.align && style[c.align] || style.left} ${c.noShrink && style.noShrink || ""}`}>{c.label}</th>
            )}
          </tr>
        </thead>
        <tbody>
          {records.map((record: T & {id: string}) =>
            <tr key={record.id} className={style.dataTr}>
              {columnsConfig.map((c, k) =>
                //<td key={k} className={`${c.tdClassName || ""} ${c.align && style[c.align] || style.left} ${c.noShrink && style.noShrink || ""}`}>
                <td key={k} style={{ width: c.width }} className={clsx(c.tdClassName, style[c.align], style.left, {[style.noShrink]: c.noShrink})} >
                  {// @ts-ignore
                  c.renderer ? c.renderer(record) : record[c.key as any]}
                </td>
              )}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

export default DataTable

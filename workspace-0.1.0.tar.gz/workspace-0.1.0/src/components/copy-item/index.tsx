import clsx from "clsx"
import React, {useState, useRef} from "react"
import style from "./index.module.scss"

const CopyItem = ({label, value, className, ...htmlProps} : {label: string, value: string} & React.HTMLAttributes<HTMLDivElement>) => {
  const [copied, setCopied] = useState<boolean>(false)
  const valueDom = useRef<any>(null)

  const handleCopy = () => {
    setCopied(true)
    valueDom?.current?.select()
    document.execCommand('Copy')
    setTimeout(() => {
      setCopied(false)
    }, 3000)
  }

  return (
    <div className={clsx(className, style.copyItem)} {...htmlProps}>
      <div className={style.label}>
        {label}
      </div>
      <div className={style.value}>
        {value}
      </div>
      {
        copied ?
          <a className={clsx(style.btn, style.btnCopied)}>已复制</a>
        :
          <a onClick={handleCopy} className={style.btn}>复制</a>
      }
      <input ref={valueDom} style={{opacity: 0, position: 'absolute', top: -1000}} value={value} />
    </div>
  )
}

export default CopyItem

import clsx from "clsx"
import React from "react"
import style from "./index.module.scss"

const ProgressBar = ({ text, percentage, className, status, ...htmlProps } : { status?: string, percentage: number, text?: string } & React.HTMLAttributes<HTMLDivElement>) => {
  return (
    <div className={clsx(style.root, className, style[status], { [style.success]: percentage === 100 })} {...htmlProps}>
      <div className={style.bar}>
        <div className={clsx(style.barFilled)} style={{width: `${percentage}%`}}> </div>
      </div>
      <div className={style.text}>
        {text || `${percentage.toFixed(1)}%`}
      </div>
    </div>
  )
}

export default ProgressBar

import React, { useMemo } from "react"
import style from "./index.module.scss"
import NavigateBeforeIcon from "../../icons/NavigateBefore"
import NavigateNextIcon from "../../icons/NavigateNext"
import { range } from "../../helper"
import Button from "../button"

type IPagination = {
  total: number
  current: number
  onChange: any
  className?: string
}

const Pagination = ({ total, current = 1, onChange, className = ""}: IPagination) => {

  const activeIndices = useMemo(() => {
    if (total <= 9) {
      return range(1, total + 1)
    }
    if (current < 5) {
      return range(1, 10)
    }
    if (current > (total - 5)) {
      return range(total - 8, total + 1)
    }
    return range(current - 4, current + 5)
  }, [total, current])

  const handleBeforeClicked = () => {
    if (current === 1) {
      return
    }
    onChange(current - 1)
  }

  const handleNextClicked = () => {
    if (current === total) {
      return
    }
    onChange(current + 1)
  }

  const handlePageClicked = (page: number) => () => {
    if (page === current) {
      return
    }
    onChange(page)
  }

  return (
    <div className={style.root + " " + className}>
      <Button variant="outline-secondary" className={style.beforeBtn} onClick={handleBeforeClicked}>
        <NavigateBeforeIcon />
      </Button>
      {activeIndices.map((i) =>
        <Button key={i} className={style.pageBtn} variant={current !== i ? "outline-secondary" : "secondary"} onClick={handlePageClicked(i)}>{i}</Button>
      )}
      <Button variant="outline-secondary" className={style.nextBtn} onClick={handleNextClicked}>
        <NavigateNextIcon />
      </Button>
    </div>
  )
}

export default Pagination
import clsx from "clsx"
import React, { useState } from "react"
import style from "./index.module.scss"

type IInput = React.DetailedHTMLProps<React.HTMLAttributes<HTMLTextAreaElement>, HTMLTextAreaElement> & {
  multiline?: boolean
  text: string
}

const Input = ({onBlur, onFocus, className, text, ...inputProps}: IInput) => {

  const [active, setActive] = useState<boolean>(false)

  const handleFocus = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    setActive(true)
    if (onBlur) {
      onFocus(e)
    }
  }

  const handleBlur = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    setActive(false)
    if (onFocus) {
      onBlur(e)
    }
  }

  return (
    <div className={clsx(className, style.root, {[style.active]: active})}>
      <textarea {...inputProps} onFocus={handleFocus} onBlur={handleBlur} value={text} />
    </div>
  )
}

export default Input

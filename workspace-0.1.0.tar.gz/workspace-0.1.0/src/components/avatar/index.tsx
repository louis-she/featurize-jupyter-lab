import React, { CSSProperties } from 'react'

type IAvatarProps = React.HTMLAttributes<HTMLDivElement> & {
  url?: string
  className?: string
  style?: CSSProperties
  imgstyle?: CSSProperties
}

const Avatar = ({className="", url="", style={}, imgstyle={}, ...htmlProps}: IAvatarProps) => {
  return (
    <div style={{width: 40, height: 40, borderRadius: '50%', overflow: 'hidden', ...style}} className={className} {...htmlProps}>
      {url && <img src={url} className="rounded" style={{width: "100%", height: "100%", ...imgstyle}} /> }
      {!url &&
        <span style={{color: "#fff", background: "#A0A6AA", borderRadius: '50%', display: "flex", alignItems: "center", justifyContent: "center", height: '100%'}}>
          <svg className="w-75 h-75 m-0" style={{fill: "#fff"}} viewBox="0 0 16 16" width="1em" height="1em" focusable="false" role="img" aria-label="person fill" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><g><path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"></path></g></svg>
        </span>
      }
    </div>
  )
}

export default Avatar

import React from "react"
import OverlayTrigger from "../overlay-trigger"
import style from "./index.module.scss"

type ITooltip = {
  id: string
  children: JSX.Element
  content: string
}

const Tooltip = ({id, children, content} : ITooltip) => {
  return (
    <>
    {content ?
      <OverlayTrigger
        trigger="hover"
        overlay={
          <div className={style.tooltipRoot}>
            {content}
          </div>
        }
      >
        {children}
      </OverlayTrigger>
      :
      <>
        {children}
      </>
    }
    </>
  )
}

export default Tooltip

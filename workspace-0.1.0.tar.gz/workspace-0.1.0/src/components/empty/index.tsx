import style from './index.module.scss'
import EmptyIcon from '../../icons/Empty'
import React from 'react'

const Empty = ({label, card=false, className=""} : {label: string, card?: boolean, className?: string}) => {
  return <div className={style.root + " " + (card ? style.card : "") + className}>
    <EmptyIcon />
    {label}
  </div>
}

export default Empty

import clsx from "clsx"
import React from "react"
import style from "./index.module.scss"

const Tag = ({
  label, variant = "primary", filled = false, icon = null, endIcon = null,
  large = false, onClick = undefined, className = "", onEndIconClick, ...htmlProps
} : React.HTMLProps<HTMLDivElement> & {
  label: string
  variant?: string
  filled?: boolean
  icon?: React.ReactNode
  endIcon?: React.ReactNode
  onEndIconClick?: any
  className?: string
  large?: boolean
}) => {
  return (
    <div
      {...htmlProps}
      onClick={onClick}
      className={clsx(
        style.root, style[variant], className, {
        [style.filled]: filled,
        [style.large]: large,
        [style.clickable]: onClick
      })}
    >
      {icon &&
      <span className={style.icon}>
        {icon}
      </span>
      }
      {label}
      {endIcon &&
      <span className={`${style.endIcon} ${onEndIconClick && style.endIconClickable || ''}`} onClick={onEndIconClick}>
        {endIcon}
      </span>
      }
    </div>
  )
}

export default Tag

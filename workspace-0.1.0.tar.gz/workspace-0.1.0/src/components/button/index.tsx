import clsx from "clsx"
import React from "react"
import { HTMLAttributes } from "react"
import style from "./index.module.scss"

type IButton = React.DetailedHTMLProps<HTMLAttributes<HTMLButtonElement>, HTMLButtonElement> & {
  size?: string
  variant?: string
  children: React.ReactNode
  disabled?: boolean
}

const Button = ({disabled=false, children, size="normal", variant="primary", className, ...otherProps}: IButton) => {

  return (
    <button disabled={disabled} className={clsx(style.btn, style["btn-" + size], style.root, className, style["btn-" + variant])} {...otherProps}>{children}</button>
  )
}

export default Button

import React, { useEffect, useMemo, useState } from "react"
import style from "./index.module.scss"
import FilterIcon from "../../icons/Filter"
import SearchIcon from "../../icons/Search"
import CloseIcon from "../../icons/Close"
import Tag from "../tag"
import Button from "../button"
import clsx from "clsx"
import OverlayTrigger from "../overlay-trigger"
import Input from "../input"

type ITag = {
  label: string
  query: string
  icon?: string
  standalone?: any
}

type IFilterItem = {
  title: string,
  tags: ITag[],
  options?: {
    mutex: boolean
  }
}

export interface IFilter {
  items: IFilterItem[],
  placeholder?: string
  className?: string
  localStorageKey?: string
  defaultItems?: string[],
  onChange: (params: {search: string, tags: ITag[]}) => void
}

const Filter = ({ placeholder, items, className, onChange, localStorageKey, defaultItems } : IFilter) => {

  const [selectedTag, setSelectedTag] = useState<ITag[]>([])
  const [searchValue, setSearchValue] = useState<string>("")
  const [inited, setInited] = useState<boolean>(false)
  const [searchFocus, setSearchFocus] = useState<boolean>(false)
  const itemsFlatten = useMemo(() => items?.map((row) => row.tags).reduce((acc, curVal) => acc.concat(curVal)), [items])

  const triggerChange = () => {
    // TODO:  增加调用频率限制
    onChange({
      search: searchValue,
      tags: selectedTag
    })
  }

  useEffect(() => {
    if (inited) {
      setTimeout(() => {
        triggerChange()
      })
    }
  }, [selectedTag, inited])

  useEffect(() => {
    if (inited && localStorageKey) {
      localStorage.setItem(localStorageKey, JSON.stringify(selectedTag))
    }
  }, [inited, selectedTag])

  useEffect(() => {
    if (defaultItems) {
      setSelectedTag(
        itemsFlatten?.filter((item) => defaultItems.includes(item.query))
      )
    }

    if (localStorageKey && localStorage.getItem(localStorageKey)) {
      let res = localStorage.getItem(localStorageKey) || "[]"
      let tag : any = null
      try {
        tag = JSON.parse(res)
      } catch {
        tag = []
      }
      setSelectedTag(tag)
    }
    setInited(true)
  }, [])

  const tagSelected = (tag: ITag) => !!selectedTag.find((stag) => stag.query === tag.query)

  const toggleTag = (tag: ITag) => () => {
    setSelectedTag(([...selectedTag]) => {
      if (tagSelected(tag)) {
        return selectedTag.filter((stag) => stag.query !== tag.query)
      } else {
        selectedTag.push(tag)
        return selectedTag
      }
    })
  }

  const clearSelectedTags = () => {
    setSelectedTag([])
  }

  const toggleMutexTag = (tag: ITag, tags: ITag[]) => () => {
    setSelectedTag(([...selectedTag]) => {
      if (tagSelected(tag)) {
        return selectedTag.filter((stag) => stag.query !== tag.query)
      } else {
        const querys = tags.map((t) => t.query)
        selectedTag = selectedTag.filter((stag) => !querys.includes(stag.query))
        selectedTag.push(tag)
        return selectedTag
      }
    })
  }

  const renderAdvancedFilter = () => {
    return (
      <div className={style.advancedFilter}>
        {items?.map(({title, tags, options}) =>
          <div key={title} className={style.category}>
            <h5>{title}</h5>
            <div className={style.tags}>
              {tags.map((tag) =>
                <Tag
                  key={tag.label}
                  className={style.tag}
                  label={tag.label}
                  onClick={(options && options.mutex) ? toggleMutexTag(tag, tags) : toggleTag(tag)}
                  filled={tagSelected(tag)}
                />
              )}
            </div>
          </div>
        )}
        <div className={style.buttons}>
          <Button
            variant="outline-secondary"
            size="sm"
            onClick={clearSelectedTags}
          >
            清空搜索项
          </Button>
        </div>
      </div>
    )
  }

  const handleKeyup = (e: React.KeyboardEvent) => {
    if (e.code === "Enter") {
      triggerChange()
    }
  }

  useEffect(() => {
    if (!searchValue && inited) {
      triggerChange()
    }
  }, [searchValue, inited])

  const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value)
  }

  const handleFocus = () => {
    setSearchFocus(true)
  }

  const handleBlur = () => {
    setSearchFocus(false)
  }

  return (
    <div className={style.root + " " + className}>
      <div className={style.searchRow}>
        <div className={clsx(style.searchInput, {focus: searchFocus})}>
          <Input
            className={style.searchInput}
            placeholder={placeholder}
            onKeyUp={handleKeyup}
            icon={<SearchIcon />}
            // @ts-ignore
            value={searchValue}
            onChange={handleOnChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
          />
        </div>
        {items &&
          <OverlayTrigger
            trigger="click"
            overlay={renderAdvancedFilter()}
          >
            <Button variant="outline-secondary" className={style.filterBtn}>
              <FilterIcon />
              更多搜索
            </Button>
          </OverlayTrigger>
        }
      </div>
      {selectedTag.length !== 0 &&
        <div className={style.selectedTag}>
          {selectedTag.map((tag) =>
            <Tag
              key={tag.label}
              className={style.tag}
              label={tag.label}
              onEndIconClick={toggleTag(tag)}
              endIcon={<CloseIcon />}
            />
          )}
        </div>
      }
    </div>
  )
}

export default Filter

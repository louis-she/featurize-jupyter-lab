import React from "react"
import style from "./index.module.scss"

const MachineStatus = ({
  label, total, current, hint, color, className, ...htmlProps
} : {
  label: string
  total: number
  current: number
  color: string
  hint?: string
} & React.HTMLProps<HTMLDivElement>) => {

  const percentage = Math.floor((current / total) * 100)

  const renderMain = () =>
    <div className={style.barContainer}>
      <div className={style.bar} style={{background: color, width: `${percentage}%`}}></div>
      {label}：{percentage}%
    </div>

  return (
    <div title={hint} className={style.root + " " + className} {...htmlProps}>
      {renderMain()}
    </div>
  )
}

export default MachineStatus

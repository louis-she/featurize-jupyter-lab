import React, { useEffect, useState, useCallback } from "react"
import clsx from "clsx"
import style from "./index.module.scss"
import { usePopper } from "react-popper"
import { Placement } from "@popperjs/core"

type IOverlayTrigger = React.HTMLProps<HTMLDivElement> & {
  trigger?: string
  overlay: any
  children: React.ReactNode
  placement?: Placement
  onActive?: any
  show?: boolean
  onShow?: any
  onHide?: any
  modifiers?: any
}

const OverlayTrigger = ({
  trigger = "click",
  placement = "auto",
  overlay,
  children,
  className,
  onActive,
  show,
  onShow,
  onHide,
  modifiers,
  ...htmlProps
} : IOverlayTrigger) => {

  const [active, setActive] = useState<boolean>(false)
  const [referenceElement, setReferenceElement] = useState(null)
  const [popperElement, setPopperElement] = useState(null)
  const { styles, attributes, update } = usePopper(referenceElement, popperElement, {
    placement,
    modifiers: [
      { name: "offset", enabled: true, options: { offset: [8, 8] } },
    ],
    strategy: "absolute",
  })

  useEffect(() => {
    if (active && onActive) {
      onActive()
    }
  }, [active])

  const documentClickedHandler = useCallback((e) => {
    if (trigger !== "click") {
      return
    }
    if (show === undefined && active === true) {
      setActive(false)
    } else if (show === true) {
      onHide()
    }
  }, [active, show])

  useEffect(() => {
    document.addEventListener("click", documentClickedHandler)
    return () => {
      document.removeEventListener("click", documentClickedHandler)
    }
  }, [documentClickedHandler])

  const handleChildrenClicked = (e: React.MouseEvent) => {
    if (trigger !== "click") {
      return
    }
    if (show === undefined) {
      setActive(true)
    } else {
      onShow()
    }
    setTimeout(() => {
      update()
    })
  }

  const handleMouseEnter = (e: React.MouseEvent) => {
    if (trigger !== "hover") {
      return
    }

    if (show === undefined) {
      setActive(true)
    } else {
      onShow()
    }
    setTimeout(() => {
      update()
    })
  }

  const handleMouseLeave = (e: React.MouseEvent) => {
    if (trigger !== "hover") {
      return
    }
    if (show === undefined && active === true) {
      setActive(false)
    } else if (show === true) {
      onHide()
    }
  }

  return (
    <div
      className={clsx(className, style.root)}
      {...htmlProps}
    >
      <div
        className={style.children}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleChildrenClicked}
        ref={setReferenceElement}
      >
        {children}
      </div>
      <div
        ref={setPopperElement}
        style={styles.popper}
        {...attributes.popper}
        onClick={(e) => e.stopPropagation()}
        className={clsx(style.overlayContainer, {[style.show]: (active || show)})}
      >
        {overlay}
      </div>
    </div>
  )
}

export default OverlayTrigger
import clsx from "clsx"
import React, { useState } from "react"
import style from "./index.module.scss"

type IInput = React.DetailedHTMLProps<React.HTMLAttributes<HTMLInputElement>, HTMLInputElement> & {
  icon?: React.ReactNode
  multiline?: boolean
}

const Input = ({icon, onBlur, onFocus, className, ...inputProps}: IInput) => {

  const [active, setActive] = useState<boolean>(false)

  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setActive(true)
    if (onBlur) {
      onFocus(e)
    }
  }

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    setActive(false)
    if (onFocus) {
      onBlur(e)
    }
  }

  return (
    <div className={clsx(className, style.root, {[style.active]: active})}>
      {icon}
      <input {...inputProps} onFocus={handleFocus} onBlur={handleBlur} />
    </div>
  )
}

export default Input

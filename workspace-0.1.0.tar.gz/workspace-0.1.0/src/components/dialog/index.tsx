import React, { useState, useEffect, useRef } from "react"
import style from "./index.module.scss"

import CheckFilledIcon from "../../icons/CheckFilled"
import CrossFilledIcon from "../../icons/CrossFilled"
import WarningFilledIcon from "../../icons/WarningFilled"
import NotificationFilledIcon from "../../icons/NotificationFilled"
import Button from "../button"
import clsx from "clsx"
import FocusTrap from 'focus-trap-react'

type IDialog = {
  title?: string
  children: React.ReactNode | string
  icon?: React.ReactNode | string
  yes?: string | React.ReactNode
  onYes?: any
  no?: string | React.ReactNode
  onNo?: any
  bodyProps?: any
  variant?: string
  bgclose?: boolean
  footer?: boolean | React.ReactNode
  header?: boolean | React.ReactNode
  show: boolean
  onHide: any
  size?: string
  leftFooter? : React.ReactNode
  maxHeight?: boolean
  contentRef?: any
  preventBackdropClose?: boolean
  dialogClassName?: string
}

let last_known_scroll_position = 0
let ticking = false

const defaultIcons : any = {
  "secondary": <NotificationFilledIcon />,
  "danger": <CrossFilledIcon />,
  "warning": <WarningFilledIcon />,
  "success": <CheckFilledIcon />,
}

const Dialog = ({
  show,
  maxHeight,
  title,
  contentRef,
  header=false,
  icon="auto",
  leftFooter,
  children,
  yes,
  no,
  size="normal",
  bodyProps,
  bgclose=true,
  preventBackdropClose=false,
  variant="secondary",
  onYes,
  onNo,
  footer=true,
  onHide,
  dialogClassName,
} : IDialog) => {

  const yesRef = useRef<any>()
  const [scrolled, setScrolled] = useState<boolean>(false)

  useEffect(() => {
    if (show) {
      yesRef.current?.focus()
    }
  }, [show])

  const handleBackdropClicked = () => {
    if (!preventBackdropClose) {
      onHide()
    }
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      onHide()
    }
  }

  const handleContentScroll = (e: React.UIEvent<HTMLDivElement>) => {
    last_known_scroll_position = e.currentTarget.scrollTop
    if (!ticking) {
      window.requestAnimationFrame(function() {
        setScrolled(last_known_scroll_position !== 0)
        ticking = false
      })
    }
    ticking = true
  }

  return (
  <>
  {show &&
    <FocusTrap active={show}>
      <div tabIndex={1} onKeyDown={handleKeyDown} className={clsx(style.root, "featurize-wrapper", style[variant], {[style.maxHeight]: maxHeight, [style.scrolled]: scrolled})}>
        <div className={style.backdrop} onClick={handleBackdropClicked}></div>
        <div style={{padding: 0}} {...bodyProps} className={clsx(style[variant], style.modalBody, style[size], dialogClassName)}>
          {header !== false &&
            <div className={style.header}>
              {header}
            </div>
          }
          <div className={style.content} onScroll={header ? handleContentScroll : undefined} ref={contentRef}>
            {icon && (icon !== "auto" || (icon === "auto" && defaultIcons[variant])) &&
              <div className={style.icon}>
                {icon === "auto" ? defaultIcons[variant] : icon}
              </div>
            }
            <div className={style.right}>
              {title && <h5>{title}</h5>}
              {children}
            </div>
          </div>
          {footer === true &&
            <div className={style.footer}>
              {leftFooter}
              <div className={style.yesandno}>
                {(no && typeof no === "string") ? <Button size="sm" variant="outline-secondary" onClick={onNo} className={style.no}>{no}</Button> : no}
                {(yes && typeof yes === "string") ? <Button size="sm" variant={variant} ref={yesRef} className={style.yes} onClick={onYes}>{yes}</Button> : yes}
              </div>
            </div>
          }
          {footer !== false && footer}
        </div>
        <div tabIndex={0} />
      </div>
    </FocusTrap>
  }
  </>
  )
}

export default Dialog
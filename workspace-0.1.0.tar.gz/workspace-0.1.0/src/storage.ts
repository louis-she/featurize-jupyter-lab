import { ChannelSubscribe, FeaturizeEvent, request, requestLab, ServerSubscribe } from "./helper"
import { IUser, IVirtualMachine } from "./types"

let subscribersCount: number = 0
let subscribers: any = {
  USER: [],
  VM: [],
}
let storage: {user: IUser, vm: IVirtualMachine, token: string, busaddr: string } = {
  user: null,
  vm: null,
  token: null,
  busaddr: null
}

const handleEventMessage = (event: FeaturizeEvent) => {
  if (!subscribers.hasOwnProperty(event.event)) {
    return
  }
  Object.values(subscribers[event.event]).forEach((callback: any) => {
    callback(event.payload)
  })
}

export function subscribe(event: string, callback: (payload: any) => void) {
  subscribersCount += 1
  if (!subscribers.hasOwnProperty(event)) {
    subscribers[event] = {}
  }
  subscribers[event][subscribersCount] = callback
  return `${event}:::${subscribersCount}`
}

export function unsubscribe (key: string) {
  const [event, id] = key.split(':::')
  delete subscribers[event][id]
}

export async function fetchUser() {
  const response = await request({ path: '/sessions' })
  storage.user = response.data
  Object.values(subscribers["USER"]).forEach((callback: any) => callback(storage.user))
}

export async function fetchVm() {
  const response = await request({ path: '/vms/info', params: {token: storage.token} })
  storage.vm = response.data
  Object.values(subscribers["VM"]).forEach((callback: any) => callback(storage.vm))
}

export async function fetchToken() {
  const response = await requestLab({ path: '/featurize/token'})
  storage.token = response.data
}

export async function fetchBusaddr() {
  const response = await requestLab({ path: '/featurize/busaddr'})
  storage.busaddr = response.data
}

export async function init(callback: any) {
  setTimeout(async () => {
    await fetchBusaddr()
    await fetchToken()
    await fetchUser()
    await fetchVm()
    callback(storage)
    new ChannelSubscribe(handleEventMessage, { channel: `user_channel_${storage.user.id}` })
    new ServerSubscribe(handleEventMessage, { token: storage.token } )
  }, 700)
}

export { storage }

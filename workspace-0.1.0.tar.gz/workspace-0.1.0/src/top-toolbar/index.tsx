import { JupyterFrontEnd, } from '@jupyterlab/application';
import { ReactWidget } from '@jupyterlab/apputils'
import React, { useCallback, useEffect, useState, useMemo } from 'react';
import style from "./index.module.scss"
import QuestionOutlineIcon from "../icons/QuestionOutline"
import NotificationsIcon from "../icons/Notifications"
import ArrowDropDownIcon from '../icons/ArrowDropDown'
import OverlayTrigger from '../components/overlay-trigger'
import clsx from 'clsx'
import { fetchUser, storage, subscribe } from "../storage"
import { INotification, IUser } from '../types';
import SavingsIcon from "../icons/Savings"
import GiftCardIcon from "../icons/CardGiftcard"
import { Autorenew } from '../icons';
import CloudIcon from "../icons/CloudQueue"
import Empty from '../components/empty';
import moment from 'moment';
import DoneIcon from "../icons/Done"
import { alertDialog, request, confirm } from '../helper';
import MachineStatus from '../components/machine-status';
import Dialog from '../components/dialog';

const TopToolbarComponent = () => {

  const [mem, setMem] = useState<any>(null)
  const [disk, setDisk] = useState<any>(null)
  const [cpu, setCpu] = useState<any>(null)
  const [gpuMem, setGpuMem] = useState<any>(null)
  const memoryPer = useMemo(() => mem === null ? 0 : Math.min(Math.round((mem.total - mem.available) / mem.total * 100), 100), [mem])
  const cpuPer = useMemo(() => cpu === null ? 0 : Math.min(Math.round(cpu * 100), 100), [cpu])
  const gpuMemPer = useMemo(() => gpuMem === null ? 0 : Math.min(Math.round(gpuMem.memUsed / gpuMem.memTotal * 100), 100), [gpuMem])
  const diskPer = useMemo(() => disk === null ? 0 : Math.min(Math.round((disk.total - disk.free) / disk.total * 100), 100), [disk])
  const [showRestoreInstanceDialog, setShowRestoreInstanceDialog] = useState(false)

  useEffect(() => {
    subscribe('MEMORY_USAGE', (payload: any) => setMem(payload))
    subscribe('CPU_USAGE', (payload: any) => setCpu(payload))
    subscribe('GPU_USAGE', (payload: any) => setGpuMem(payload))
    subscribe('DISK_USAGE', (payload: any) => setDisk(payload))
    subscribe('USER', (payload: any) => setUser(payload))
  }, [])

  // @ts-ignore
  const [user, setUser] = useState<IUser>(storage.user)
  const [notifications, setNotifications] = useState<INotification[]>([])

  const notificationsUpdateCallback = useCallback((notification: INotification) => {
    notifications.unshift(notification)
    setNotifications(notifications)
  }, [notifications])

  const asRead = async (notification: INotification) => {
    await request({
      path: `/notifications/${notification.id}/read`,
      method: 'post'
    })
    fetchNotifications()
  }

  useEffect(() => {
    subscribe('NEW_NOTIFICATION', notificationsUpdateCallback)
  }, [])

  useEffect(() => {
    // notifications 变化时，检测是否有弹窗通知
    notifications.forEach((notification) => {
      if (notification.sendDialog === "pending") {
        alertDialog({
          title: notification.title,
          content: notification.content,
          preventBackdropClose: true
        })
        asRead(notification)
      }
    })
  }, [notifications])

  const fetchNotifications = async () => {
    const response = await request({ path: "/notifications" })
    setNotifications(response.data.records)
  }

  useEffect(() => {
    fetchNotifications()
  }, [])

  const markAllRead = async () => {
    await request({
      path: '/notifications/all/read',
      method: 'post'
    })
    fetchNotifications()
  }

  const handleMarkAsRead = (notification: INotification) => async (event: React.MouseEvent) => {
    event.stopPropagation()
    await asRead(notification)
  }

  const restoreInstance = async () => {
    const result = await confirm({
      level: "warning",
      title: "退还实例",
      content: "确定要退还该实例吗？",
    })
    if (!result) {
      return
    }

    setShowRestoreInstanceDialog(true)

    const response = await request({
      path: `/virtual_machine/${storage.vm.id}`,
      method: 'DELETE',
    })

    if (response.status === 10014) {
      alertDialog({
        level: "error",
        title: "长租实例",
        content: "长期租用实例不支持提前退还，可将实例标记为到期自动退还。"
      })
      return
    }

    if (response.status === 0) {
      location.href = "https://featurize.cn/"
    }
  }

  const renderNotificationsPopover = () =>
    <div className={style.notificationPopover + " popover"}>
      <div className={style.notificationPopoverHead}>
        <h5>通知</h5>
        <div className={style.operations}>
          {notifications.length !== 0 && <a href="javascript:;" onClick={markAllRead}>全部标记为已读</a> }
        </div>
      </div>
      <div className={style.notificationPopoverBody}>
        {notifications.length === 0 &&
          <Empty label="暂无未读通知" />
        }
        {notifications.length !== 0 && notifications.map((notification) =>
          <a className={style.notificationItem} key={notification.id} target="_blank" href={`https://featurize.cn${notification.url}` || `https://featurize.cn/notifications/${notification.id}`}>
            <div className={style.notificationItemContent}>
              <div className={style.notificationTitle}>
                {notification.title}
              </div>
              <div className={style.notificationStartTime}>
                {moment(notification.sendRangeStart).format("L LT")}
              </div>
            </div>
            <a className={style.markAsRead} onClick={handleMarkAsRead(notification)}>
              <DoneIcon />
            </a>
          </a>
        )}
      </div>
    </div>

  const renderUserPopover = () =>
  <div className={style.userPopover + " popover"}>
    <div className={style.title}>
      <div className={style.titleName}>
        <span className={style.name}>{user?.name}</span>
        <span className={style.level}>{user?.level || 1}级</span>
      </div>
      <div className={style.billing}>
        <span className={style.balance}>
          <SavingsIcon />
          余额：{user?.withdrawableBalance.toFixed(0)}
        </span>
        <span className={style.coupon}>
          <GiftCardIcon />
          代金券：{user?.nonWithdrawableBalance.toFixed(0)}
        </span>
      </div>
      <div className={style.storage}>
        <CloudIcon /> 云盘用量 {(user?.cloudUsage)?.toFixed(1) || 0} GB / {user?.cloudQuota} GB
      </div>
    </div>
    <a target="_blank" href="https://featurize.cn/me/profile" className={style.item}>
      <div>
        <div className={style.itemTitle}>个人信息</div>
        <div className={style.itemDesc}>等级、用户名、头像、社交账号等</div>
      </div>
    </a>
    <a target="_blank" href="https://featurize.cn/me/billing" className={style.item}>
      <div>
        <div className={style.itemTitle}>账户信息</div>
        <div className={style.itemDesc}>充值、使用记录、发票等</div>
      </div>
    </a>
    <a target="_blank" href="https://featurize.cn/me/welfare" className={style.item}>
      <div>
        <div className={style.itemTitle}>福利中心</div>
        <div className={style.itemDesc}>带新奖励，认证奖励等</div>
      </div>
    </a>
    <a target="_blank" href="https://featurize.cn/me/secure" className={style.item}>
      <div >
        <div className={style.itemTitle}>安全设置</div>
        <div className={style.itemDesc}>密码、手机、邮箱等</div>
      </div>
    </a>
    <div className={style.userOperations}>
      <a className={clsx(style.item, style.restoreInstance)} onClick={restoreInstance}>
        退还实例
      </a>
    </div>
  </div>

  return (
    <div className={style.root}>
      <OverlayTrigger
        trigger="click"
        overlay={renderUserPopover()}
        className={clsx(style.item, style.avatar)}
        onActive={fetchUser}
      >
        <a href="javascript:;">
          <img src={storage.user.avatar} />
          <ArrowDropDownIcon />
        </a>
      </OverlayTrigger>
      <OverlayTrigger
        trigger="click"
        overlay={renderNotificationsPopover()}
        className={clsx(style.item, style.notification)}
      >
        <a href="javascript:;">
          {notifications.length !== 0 &&
            <div className={style.redDot}></div>
          }
          <NotificationsIcon />
        </a>
      </OverlayTrigger>
      <div className={style.item}>
        <a href="https://docs.featurize.cn" target="_blank">
          <QuestionOutlineIcon />
        </a>
      </div>
      <MachineStatus className={style.machineStatus} label="磁盘" total={100} current={diskPer} color="#D2BFFD" />
      <MachineStatus className={style.machineStatus} label="内存" total={100} current={memoryPer} color="#C3CCFE" />
      <MachineStatus className={style.machineStatus} label="CPU" total={100} current={cpuPer} color="#FDC3BF" />
      {gpuMem !== null && gpuMem.memTotal !== 0 &&
        <MachineStatus className={style.machineStatus} label="显存" total={100} current={gpuMemPer} color="#96E7B6" />
      }
      <Dialog
        show={showRestoreInstanceDialog}
        onHide={() => {}}
        icon={<Autorenew className={style.spinIcon} />}
      >
        <div className={style.dialogContent}>
          <h5>正在归还实例</h5>
          <p>归还后请确保「我租用的实例」列表中没有该实例。</p>
        </div>
      </Dialog>
    </div>
  )
}

export class TopToolbar extends ReactWidget {
  constructor(app: JupyterFrontEnd) {
    super()
    this.addClass('featurize-top-toolbar')
    this.addClass('featurize-wrapper')
  }

  render(): JSX.Element {
    return <TopToolbarComponent />
  }
}
import React, { useEffect, useState } from "react"
import CopyItem from "../components/copy-item"
import Dialog from "../components/dialog"
import Textarea from "../components/Textarea"
import style from "./index.module.scss"
import { storage } from "../storage"
import { requestLab } from "../helper"
import Button from "../components/button"
import Tag from "../components/tag"
import { Close, VpnKey } from "../icons/"
import PopupConfirm from "../components/popup-confirm"

type IKey = {
  hash: string
  comment: string
  keydata: string
}

const SshDialog = ({ onHide } : {onHide: any}) => {

  const [pending, setPending] = useState<boolean>(false)
  const [publicKey, setPublicKey] = useState<string>("")
  const [publicKeys, setPublicKeys] = useState<IKey[]>([])

  const fetch = async () => {
    const response = await requestLab({ path: '/featurize/ssh' })
    setPublicKeys(response.data)
  }

  useEffect(() => { fetch() }, [])

  const submitPublicKey = async () => {
    setPending(true)
    const response = await requestLab({
      path: '/featurize/ssh',
      method: 'POST',
      data: {
        sshkey: publicKey
      }
    })
    if (response.status !== 0) {
      setPending(false)
      return alert('请输入有效的 SSH 公钥文本')
    }
    await fetch()
    setPending(false)
    setPublicKey('')
  }

  const handleRemoveKey = (key: IKey) => async () => {
    await requestLab({
      path: '/featurize/ssh',
      method: 'delete',
      data: {
        keyhash: key.hash
      }
    })
    fetch()
  }

  return (
    <Dialog
      size="large"
      show
      onHide={onHide}
      no="取消"
      onNo={onHide}
      icon={false}
      footer={false}
    >
      <h5>使用 SSH 连接服务器</h5>
      <div className={style.configSection}>
        <CopyItem label="地址" value="workspace.featurize.cn" />
        <CopyItem label="端口" value={storage.vm.sshPort} />
        <CopyItem label="用户" value="featurize" />
        <CopyItem label="密码" value={storage.vm.featurizePassword} />
        <CopyItem label="命令" value={`ssh featurize@workspace.featurize.cn -p ${storage.vm.sshPort}`} />
      </div>
      <div className={style.publicKey}>
        <h5>添加公钥</h5>
        <div className={style.keys}>
          {publicKeys.map((key) =>
            <Tag
              icon={<VpnKey />}
              variant="secondary"
              className={style.key}
              label={`${key.comment}`}
              endIcon={
                <PopupConfirm content="确定要删除该公钥吗？" onOK={handleRemoveKey(key)}>
                  <Close />
                </PopupConfirm>
              }
              onEndIconClick={() => {}}
            />
          )}
        </div>
        <Textarea
          placeholder="请将公钥文本粘贴到这里"
          text={publicKey}
          onChange={(e) => {
            const ele = e.target as HTMLTextAreaElement
            setPublicKey(ele.value)
          }}
        />
        <div className={style.operations}>
          <Button
            onClick={submitPublicKey}
            variant="secondary"
            size="sm"
            disabled={pending}
          >
            添加
          </Button>
        </div>
      </div>
    </Dialog>
  )
}

export default SshDialog

import clsx from "clsx"
import React, { useEffect, useState, useCallback } from "react"
import Avatar from "../components/avatar"
import Button from "../components/button"
import DataTable from "../components/datatable"
import Dialog from "../components/dialog"
import Filter, { IFilter } from "../components/filter"
import Pagination from "../components/pagination"
import Tag from "../components/tag"
import Tooltip from "../components/tooltip"
import { alertDialog, atom, humanFileSize, request, requestLab } from "../helper"
import { Check, HourglassTop } from "../icons"
import { subscribe, unsubscribe } from "../storage"
import { IDataset, ITag } from "../types"
import { Clipboard } from '@jupyterlab/apputils';
import style from "./index.module.scss"

const DatasetDialog = ({ onHide } : {onHide: any}) => {

  const [tags, setTags] = useState<ITag[]>([])
  const [currentPage, setCurrentPage] = useState<number>(1)
  const [totalPage, setTotalPage] = useState<number>(0)
  const [datasets, setDatasets] = useState<IDataset[]>([])
  const [filter, setFilter] = useState<any>({})
  const [init, setInit] = useState<boolean>(false)

  const fetchData = useCallback(async () => {
    const response = await request({
      path: "/datasets",
      params: {page: currentPage - 1, ...filter}
    })
    setDatasets(response.data.records)
    setTotalPage(response.data.pagination.total)
  }, [currentPage, filter])

  useEffect(() => {
    setTimeout(() => {
      setInit(true)
      console.log("inited!")
    }, 1000)
  }, [])

  useEffect(() => {
    if (!init) return
    fetchData()
  }, [init, currentPage, filter])

  useEffect(() => {
    (async function() {
      const response = await request({
        path: "/tags",
        params: {resource: "dataset"}
      })

      setTags(response.data)
    }())
  }, [])

  const updateDataset = (datasets: IDataset[], dataset: IDataset) => {
    const index = datasets.findIndex((item) => item.id === dataset.id)
    if (index !== -1) {
      datasets[index] =dataset
      return datasets
    } else {
      return datasets
    }
  }

  useEffect(() => {
    const datasetSubscription = subscribe('DATASET_UPDATE', (dataset: IDataset) => {
      setDatasets((_datasets) => updateDataset([..._datasets], dataset))
    })
    return () => { unsubscribe(datasetSubscription) }
  }, [])

  const handleFilterChanged : IFilter['onChange'] = (data) => {
    setFilter({
      search: data.search,
      query: data.tags.filter((t) => !t.standalone).map((t) => t.query).join(","),
      ...atom(data.tags.filter((t) => t.standalone).map((t) => t.query.split(":")))
    })
  }

  const handleSelectClick = (dataset: IDataset) => async () => {
    request({
      path: `/datasets/${dataset.id}/used`,
      method: 'POST'
    })
    const response = await request({ path: '/oss_credentials' })
    await requestLab({
      path: '/featurize/datasets/download',
      method: 'POST',
      data: {
        dataset,
        credentials: response.data
      }
    })
    onHide()
  }

  const handleCopy = (dataset: IDataset) => () => {
    Clipboard.copyToSystem(`featurize dataset download ${dataset.id}`);
    onHide()
    alertDialog({
      level: "success",
      content: "已复制到剪贴板，在终端或 Notebook 可直接运行"
    })
  }

  return (
    <Dialog
      size="mega"
      show
      onHide={onHide}
      no="取消"
      onNo={onHide}
      icon={false}
      maxHeight
      leftFooter={
        <Pagination current={currentPage} total={totalPage} onChange={(page: number) => {setCurrentPage(page)}} />
      }
    >
      <div className={style.topbar}>
        <div>
          <h5>添加数据集至实例</h5>
        </div>
        <div className={clsx(style.filterContainer, "paper", "featurize-wrapper")}>
          <Filter localStorageKey="workspace-dataset-filter" defaultItems={["category:mine"]} onChange={handleFilterChanged} className={style.filter} placeholder="搜索数据集名称，按回车开始搜索" items={[
            {
              title: "标签",
              tags: tags.map((tag) => ({
                label: tag.name, query: `tag:${tag.id}`, icon: ""
              })),
            },
            {
              title: "数据集大小",
              tags: [
                {label: "0MB ~ 50MB", query: "size:0-50000000", icon: ""},
                {label: "50MB ~ 1GB", query: "size:50000000-1000000000", icon: ""},
                {label: "1GB ~ 5GB", query: "size:1000000000-5000000000", icon: ""},
                {label: "5GB ~ 200GB", query: "size:5000000000-200000000000", icon: ""},
              ]
            },
            {
              title: "数据集来源",
              tags: [
                {label: "我上传的", query: "category:mine", icon: "", standalone: true},
                {label: "官方维护", query: "category:featurize", icon: "", standalone: true},
              ],
              options: { mutex: true }
            }
          ]} />
        </div>
      </div>
      <div className={style.dataTable}>
        <DataTable<IDataset> records={datasets} columnsConfig={[{
          label: "数据集名称",
          renderer: (dataset) =>
            <a href={`https://featurize.cn/datasets/${dataset.id}`} target="_blank">
              {dataset.name}
            </a>
        }, {
          label: "本地缓存",
          renderer: (dataset) =>
          <>
            {dataset.cacheProgress === 100 ?
            <>
              <Tag label="已缓存" variant="success" icon={<Check />} />
            </>
              :
              <Tooltip id={dataset.id} content={`请等待缓存完毕后再使用数据集，缓存该数据集大概需要 ${Math.floor((dataset.size / (1024 ** 2 * 60 * 5))) + 1} 分钟`}>
                <Tag label="正在缓存" variant="warning" icon={<HourglassTop />} />
              </Tooltip>
            }
          </>
        }, {
          label: "标签",
          renderer: (dataset) =>
            <span className={style.tagsContainer}>{dataset.tags.map((tag) => <Tag key={tag.id} label={tag.name} variant={tag.color} />)}</span>
        }, {
          label: "数据集大小",
          renderer: (dataset) =>
            <span>{humanFileSize(dataset.size)}</span>
        }, {
          label: "被使用次数",
          key: "usedCount"
        }, {
          label: "上传者",
          width: "160px",
          renderer: (dataset) =>
            <div className={style.uploaderContainer}>
              <Avatar style={{width: 24, height: 24}} url={dataset.uploader.avatar} />
              <span>{dataset.uploader.name}</span>
            </div>
        }, {
          label: "操作",
          noShrink: true,
          width: "225px",
          renderer: (dataset) =>
            <div className={style.operationContainer}>
              {dataset.cacheProgress === 100 ?
                <Button variant="outline-secondary" onClick={handleCopy(dataset)}>复制命令</Button>
                :
                <Tooltip  id={dataset.id} content={`请等待缓存完毕后再使用数据集，缓存该数据集大概需要 ${Math.floor((dataset.size / (1024 ** 2 * 60 * 5))) + 1} 分钟`}>
                  <Button variant="outline-secondary" disabled>复制命令</Button>
                </Tooltip>
              }
              {dataset.cacheProgress === 100 ?
                <Button variant="outline-secondary" onClick={handleSelectClick(dataset)}>下载</Button>
                :
                <Tooltip  id={dataset.id} content={`请等待缓存完毕后再使用数据集，缓存该数据集大概需要 ${Math.floor((dataset.size / (1024 ** 2 * 60 * 5))) + 1} 分钟`}>
                  <Button variant="outline-secondary" disabled>下载</Button>
                </Tooltip>
              }
            </div>
        }]} />
      </div>
    </Dialog>
  )
}

export default DatasetDialog

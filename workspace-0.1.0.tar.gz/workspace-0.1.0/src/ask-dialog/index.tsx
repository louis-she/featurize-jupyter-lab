import React, { useEffect, useRef, useState } from "react";
import update from 'immutability-helper';
import Dialog from "../components/dialog";
import style from "./index.module.scss";
import "highlight.js/styles/github.css";
import clsx from "clsx";
import moment from "moment";
import Button from "../components/button";
import { fetchUser, storage, subscribe, unsubscribe } from "../storage";
import { request } from "../helper";
import Tag from "../components/tag";
import { marked } from "marked";
import hljs from "highlight.js";

// const tokenizer: any = {
//   fences(src: any) {
//     const cap = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/.exec(src);
//     if (cap) {
//       const raw = cap[0];
//       const text = indentCodeCompensation(raw, cap[3] || '');

//       return {
//         type: 'code',
//         raw,
//         lang: cap[2] ? cap[2].trim().replace(this.rules.inline._escapes, '$1') : cap[2],
//         text
//       };
//     }
//   }};


interface MessageProps {
  id: string;
  side: "left" | "right";
  userAvatar: string;
  userName: string;
  createdAt: Date;
  content: string;
}

const Message = ({
  userAvatar,
  userName,
  createdAt,
  content,
  side,
}: MessageProps) => {
  return (
    <div className={clsx(style.message, style[side])}>
      <div className={style.left}>
        <img className={style.avatar} src={userAvatar} />
      </div>
      <div className={style.right}>
        <div className={style.userName}>
          {userName}
          <div className={style.createdAt}>
            {moment(createdAt).format("MM-DD HH:mm")}
          </div>
        </div>
        <div className={style.content}>
          <div className="markdown-body" dangerouslySetInnerHTML={{__html: marked.parse(content, {
            highlight: (code, lang) => {
              const language = hljs.getLanguage(lang) ? lang : 'python';
              return hljs.highlight(code, { language }).value;
            },
            langPrefix: 'hljs language-',
          })}} />
        </div>
      </div>
    </div>
  );
};

const AskDialog = ({ onHide }: { onHide: any }) => {

  const [messages, setMessages] = useState<MessageProps[]>([]);
  const [answering, setAnsering] = useState<boolean>(false);
  const [freeCounts, setFreeCounts] = useState<number>(0);
  const [enabled, setEnabled] = useState<boolean>(storage.user.meowtronEnabled);
  const contentRef = useRef(null)
  const helloMessage = useRef<string>(null)

  useEffect(() => {
    (async () => {
      const res = await request({
        path: "/meowtron",
        method: "get",
      })
      setFreeCounts(res.data.freeCounts)
      let messages : MessageProps[] = []
      let lastMessage : any = res.data.messages.length !== 0 ? res.data.messages[0] : null;
      if (moment().diff(moment(lastMessage.created), "minutes") > 5) {
        messages.unshift({
          id: "hello",
          side: "left",
          userAvatar: "https://featurize-public.oss-cn-beijing.aliyuncs.com/robot.png",
          userName: "Meowtron",
          createdAt: new Date(),
          content: res.data.helloMessage
        })
        messages.unshift(
          {
            id: "hello",
            side: "right",
            userAvatar: "breakline",
            userName: "breakline",
            createdAt: lastMessage ? lastMessage.created : new Date(),
            content: "breakline",
          },
        )
        helloMessage.current = res.data.helloMessage
      }

      res.data.messages.forEach((e: any) => {
        console.log(lastMessage.sessionId, e.sessionId)
        if (lastMessage.sessionId !== e.sessionId) {
          lastMessage = e
          messages.unshift(
            {
              id: e.id,
              side: "right",
              userAvatar: "breakline",
              userName: "breakline",
              createdAt: e.created,
              content: "breakline",
            },
          )
        }
        messages.unshift(
          {
            id: e.id,
            side: e.role === "user" ? "right" : "left",
            userAvatar: e.role === "user" ? storage.user.avatar : "https://featurize-public.oss-cn-beijing.aliyuncs.com/robot.png",
            userName: e.role === "user" ? storage.user.name : "Meowtron",
            createdAt: e.created,
            content: e.content || "",
          },
        )
      });
      setMessages(messages)
    })()
  }, [])

  const rendering = useRef<boolean>(false)
  const renderedContent = useRef<string>("")
  const renderingCode = useRef<boolean>(false)

  useEffect(() => {
    const handler = subscribe("ASK_RESULT", (payload: MessageProps) => {
      rendering.current = true
      // update the last message's content to concat the payload
      if (!answering) return
      setMessages((messages) => {
        const message = messages.find((m) => m.id === payload.id && m.side === "left")
        if (!message) return messages
        let newMessage;
        if (payload.content.indexOf("[DONE]") !== -1) {
          setAnsering(false)
          textareaEl.current.textContent = ''
          setTimeout(() => {
            textareaEl.current.focus()
            rendering.current = false
            renderedContent.current = ""
            renderingCode.current = false
          })
          newMessage = update(message, {
            content: {
              $set: renderedContent.current,
            },
          })
        } else {
          renderedContent.current += payload.content
          const codePieces = renderedContent.current.split("```")
          let setString: string;
          console.log(codePieces)
          if (codePieces.length % 2 === 0) {
            // setString = message.content.substring(0, message.content.length - 54) + payload.content + "\n```" + "<span class='position-indicator'>&nbsp;</span></p>"
            setString = renderedContent.current + "\n```\n<span class='position-indicator'>&nbsp;</span></p>"
          } else {
            // setString = message.content.substring(0, message.content.length - 50) + payload.content + "<span class='position-indicator'>&nbsp;</span></p>"
            setString = renderedContent.current + "<span class='position-indicator'>&nbsp;</span></p>"
          }
          newMessage = update(message, {
            content: {
              $set: setString
            },
          })
        }
        return update(messages, {
          $splice: [[messages.length - 1, 1, newMessage]]
        })
      })
    });
    return () => {
      unsubscribe(handler)
    }
  }, [answering]);

  useEffect(() => {
    contentRef.current.scrollTop = contentRef.current.scrollHeight
  }, [messages])

  const ask = async () => {
    setAnsering(true)
    const res = await request({
      path: "/meowtron",
      method: "POST",
      data: {
        prompt: textareaEl.current.textContent,
      }
    })
    // add user message
    setMessages((messages) => {
      if (textareaEl.current.textContent === "/new") {
        setTimeout(() => {
          textareaEl.current.textContent = ''
          setAnsering(false)
          setTimeout(() => {
            textareaEl.current.focus()
          })
        })
        return update(messages, {
          $push: [
            {
              id: "breakline",
              side: "right",
              userAvatar: "breakline",
              userName: "breakline",
              createdAt: new Date(),
              content: "breakline",
            },
            {
              id: res.data.id,
              side: "left",
              userAvatar: "https://featurize-public.oss-cn-beijing.aliyuncs.com/robot.png",
              userName: "Meowtron",
              createdAt: new Date(),
              content: "新的对话已开启，有什么我可以帮助您的吗？",
            },
          ],
        });
      } else {
        setFreeCounts((freeCounts) => freeCounts - 1)
        return update(messages, {
          $push: [
            {
              id: res.data.id,
              side: "right",
              userAvatar: storage.user.avatar,
              userName: storage.user.name,
              createdAt: new Date(),
              content: `<p>${textareaEl.current.textContent}</p>`,
            },
            {
              id: res.data.id,
              side: "left",
              userAvatar: "https://featurize-public.oss-cn-beijing.aliyuncs.com/robot.png",
              userName: "Meowtron",
              createdAt: new Date(),
              content: `<p><span class='position-indicator'>&nbsp;</span></p>`,
            },
          ],
        });
      }
    });
  }

  const handleKeyDown = async (e: React.KeyboardEvent<HTMLDivElement>) => {
    // if enter submit form, else use default
    if (e.code === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      await ask();
    }
  };

  const textareaEl = useRef<HTMLDivElement>(null);

  return (
    <Dialog
      size="large"
      show
      onHide={onHide}
      onNo={onHide}
      icon={false}
      contentRef={contentRef}
      dialogClassName={style.dialogContent}
      footer={
        <div>
          {!enabled ? (
            <div className={clsx(style.footerEditor, style.disabled)}>
              向 Meowtron 提问为付费服务，价格为 0.1
              元/次，请点击右侧按钮后启用该服务{" "}
              <Button variant="secondary" size="sm" onClick={async () => {
                setEnabled(true)
                await request({
                  path: "/sessions",
                  method: "patch",
                  data: { meowtron_enabled: true }
                })
                await fetchUser()
              }}>
                启用服务
              </Button>
            </div>
          ) : (
            <div
              ref={textareaEl}
              suppressContentEditableWarning={true}
              contentEditable={!answering}
              onChange={(e) => {
                textareaEl.current.textContent = e.currentTarget.innerText
              }}
              className={clsx(style.footerEditor, {[style.disabled]: answering})}
              placeholder="请详细描述问题，并按回车发送"
              onKeyDown={handleKeyDown}
              onPaste={(event) => {
                event.preventDefault();
                const text = event.clipboardData.getData('text/plain');
                const plainText = text.replace(/(<([^>]+)>)/gi, '');
                document.execCommand('insertHTML', false, plainText);
              }}
            />
          )}
        </div>
      }
    >
      <div className={style.conversations} style={{width: "100%"}}>
        {messages.map((message, index) => {
          return (message.userAvatar === "breakline" ?
            <div className={style.divider}>
              <span>{moment(message.createdAt).format("MM-DD HH:mm")}</span>
            </div>
            :
            <Message key={index} {...message} />)
        })}
      </div>
      {!answering &&
      <div className={style.afterConversation}>
        {freeCounts > 0 ?
          <Tag label={`今日还可以免费提问 ${freeCounts} 次`} className={style.freeQuota} />
        :
          <Tag label={"今日的免费配额已耗尽，接下来的提问费用为 0.1 元/次"} className={style.freeQuota} />
        }
      </div>
      }
    </Dialog>
  );
};

export default AskDialog;

import axios, { AxiosRequestConfig } from "axios"
import React, { useState } from "react"
// @ts-ignore
import ReactDOM from "react-dom"
import Dialog from './components/dialog'
import CheckFilledIcon from './icons/CheckFilled'
import CrossFilledIcon from './icons/CrossFilled'
import WarningFilledIcon from './icons/WarningFilled'
import NotificationFilledIcon from './icons/NotificationFilled'
import { ServerConnection } from '@jupyterlab/services';
import { URLExt } from '@jupyterlab/coreutils';
// @ts-ignore
import camelCase from 'lodash.camelcase'
import { storage } from "./storage"

type IRequest = AxiosRequestConfig & {
  path: string
  camelize?: boolean
}

type IAlert = {
  content: string
  title: string
  level: string
  preventBackdropClose: boolean
}

const atom = (input: Array<any>) => {
  const ret : any = {}
  input.forEach((value: any) => {
    ret[value[0]] = value[1]
  })
  return ret
}

export async function requestLab({
  path,
  method = 'GET',
  data = null
} : {path: string, method?: string, data?: any}): Promise<any> {
  let fullRequest;
  method = method.toUpperCase()
  if (data === null) {
    fullRequest = {
      method: method
    }
  } else if (method === 'DELETE' || method === 'GET' || method === 'HEAD') {
    fullRequest = {
      method: method,
    }
    path = path + '?' + Object.keys(data).map(function(key) {
      return key + '=' + data[key]
    }).join('&');
  } else {
    fullRequest = {
      method: method,
      body: (data instanceof FormData) ? data : JSON.stringify(data)
    }
  }
  let setting = ServerConnection.makeSettings()
  let fullUrl = URLExt.join(setting.baseUrl, path)
  const response = await ServerConnection.makeRequest(fullUrl, fullRequest, setting)
  return await response.json();
}

const request = async ({ autoAlert = false, camelize = true, ...props }: IRequest & {autoAlert?: Boolean}) => {
  const url = `https://${storage.busaddr}/bus/api/v1${props.path}`
  let response;
  try {
    response = await axios({
      url,
      withCredentials: true,
      ...props
    })
  } catch (e: any) {
    if (e.response.status == 500 && autoAlert) {
      return alertDialog({
        title: "服务器内部错误",
        content: "Featurize 工程师已经收到报警通知，会第一时间修复，请稍后再试。若长时间未解决，请联系 Featurize 平台工作人员",
        level: "error"
      })
    }
    if (e.response.status == 403 && autoAlert) {
      return alertDialog({
        title: "错误",
        content: "你没有权限访问该资源",
        level: "error"
      })
    }
    if (e.response.status == 401 && autoAlert) {
      return alertDialog({
        title: "未登录账号",
        content: "请登录后再执行该操作",
        level: "warning"
      })
    }
    if (e.response.status == 422 && autoAlert) {
      return alertDialog({
        title: "错误",
        content: "请尝试重新操作",
        level: "warning"
      })
    }
    throw e
  }

  if (camelize) {
    return camelizeKeys(response.data)
  }

  return response.data
}

let confirmResolve : any = null

const confirm = (probs: Partial<IAlert>) => {

  ReactDOM.render(
    <ConfirmDialog {...probs} />,
    document.getElementById("__global_root__")
  )

  return new Promise<boolean>((resolve) => {
    confirmResolve = resolve
  })
}


// @ts-ignore
const dialogCfg = {
  info: {
    defaultTitle: "提示",
    icon: <NotificationFilledIcon />,
    className: 'global-alert global-alert-info',
    variant: 'secondary'
  },
  warning: {
    defaultTitle: "警告",
    icon: <WarningFilledIcon />,
    className: "global-alert global-alert-warning",
    variant: 'warning'
  },
  error: {
    defaultTitle: "错误",
    icon: <CrossFilledIcon />,
    className: "global-alert global-alert-error",
    variant: 'danger'
  },
  success: {
    defaultTitle: "成功",
    icon: <CheckFilledIcon />,
    className: "global-alert global-alert-success",
    variant: 'success'
  }
}

const ConfirmDialog = ({level="info", title="", content=""}: Partial<IAlert>) => {
  const [show, setShow] = useState(true)
  // @ts-ignore
  const cfg = dialogCfg[level]

  return (
    <Dialog
      title={title === "" ? cfg?.defaultTitle : title}
      show={show}
      icon={cfg?.icon}
      onHide={() => {
        setShow(false)
        confirmResolve(false)
        ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__') as HTMLElement)
      }}
      yes="确定"
      bodyProps={{ className: cfg?.className }}
      variant={cfg?.variant}
      no="算了"
      onNo={() => {
        setShow(false)
        confirmResolve(false)
        ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__') as HTMLElement)
      }}
      onYes={() => {
        setShow(false)
        confirmResolve(true)
        ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__') as HTMLElement)
      }}
    >
      {content}
    </Dialog>
  )
}

const AlertDialog = ({level="info", title="", content="", preventBackdropClose=false}: Partial<IAlert>) => {
  const [show, setShow] = useState(true)

  // @ts-ignore
  const cfg = dialogCfg[level]

  return (
    <Dialog
      title={title === "" ? cfg?.defaultTitle : title}
      show={show}
      icon={cfg?.icon}
      preventBackdropClose={preventBackdropClose}
      onHide={() => {
        setShow(false)
        ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__') as HTMLElement)
      }}
      yes="知道了"
      bodyProps={{ className: cfg?.className }}
      variant={cfg?.variant}
      onYes={() => {
        setShow(false)
        ReactDOM.unmountComponentAtNode(document.getElementById('__global_root__') as HTMLElement)
      }}
    >
      <div dangerouslySetInnerHTML={{__html: content}} />
    </Dialog>
  )
}

const alertDialog = (probs: Partial<IAlert>) => {
  if (typeof window === 'undefined') return
  ReactDOM.render(
    <AlertDialog {...probs} />,
    document.getElementById("__global_root__")
  )
}

const isMobileNumber = (mobile: string) => {
  return /^1\d{10}$/.test(mobile)
}

const isEmail = (email: string) => {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  return re.test(String(email).toLowerCase())
}

const camelizeKeys = (obj: any) : any => {
  if (Array.isArray(obj)) {
    return obj.map(v => camelizeKeys(v))
  } else if (obj !== null && obj.constructor === Object) {
    return Object.keys(obj).reduce(
      (result, key) => ({
        ...result,
        [camelCase(key)]: camelizeKeys(obj[key]),
      }),
      {},
    )
  }
  return obj
}

const asyncDebounce = (callable: any, deplay: number) => {
  let allow = true
  let handler : any = 0

  const real = async (...args: any) => {
    if (allow) {
      return await callable.apply(this, args)
    }
    allow = false
    clearTimeout(handler)
    handler = setTimeout(() => {
      allow = true
    }, deplay)
    return undefined
  }
  return real
}

const normValidDomSelector = (s: any) => {
  return s.replace(/[.()\s]/ig, '')
}

export interface FeaturizeEvent {
  event: string;
  payload: any;
}

type MessageCallback = (message: FeaturizeEvent) => void

abstract class BaseSubscribe<T> {
  onmessage: MessageCallback
  socket: WebSocket | null
  socketArgs: T
  interval: any

  constructor(onmessage: MessageCallback, socketArgs: T) {
    this.onmessage = onmessage
    this.socketArgs = socketArgs
    this.socket = null
    this.interval = null
    this.initSocket()
  }

  initSocket = () => {
    this.socket = this.createSocket(this.socketArgs)
    this.socket.onmessage = (message: MessageEvent) => {
      if (message.data === 'featurize.pong') {
        return
      }
      this.onmessage(camelizeKeys(JSON.parse(message.data)));
    }

    this.socket.onclose = () => {
      setTimeout(() => {
        console.log('try to reconnect')
        this.initSocket()
      }, 10000)
    }

    this.socket.onerror = () => {
      console.error('Socket error')
      this?.socket?.close()
    }

    this.interval = setInterval(() => {
      try {
        this?.socket?.send('featurize.ping')
      } catch {
        console.log('Socket error')
      }
    }, 15000)
  }

  abstract createSocket(socketArgs: T) : WebSocket;

  close() {
    clearInterval(this.interval)
    this.socket?.close()
  }
}

export class ChannelSubscribe extends BaseSubscribe<{channel: string}> {
  createSocket({channel = 'common'}) {
    // @ts-ignore
    return new WebSocket(`wss://${storage.busaddr}/bus/channel?channel_name=${channel}`);
  }
}

export class ServerSubscribe extends BaseSubscribe<{token: string}> {
  createSocket({token = ''}) {
    return new WebSocket(`wss://${storage.busaddr}/bus/websocket/virtual_machine_subscribe?token=${token}`);
  }
}

export function humanFileSize(bytes: number, si: boolean = true) {
  let thresh = si ? 1000 : 1024
  if (Math.abs(bytes) < thresh) {
      return bytes + ' B';
  }
  let units = si
      ? ['kB','MB','GB','TB','PB','EB','ZB','YB']
      : ['KiB','MiB','GiB','TiB','PiB','EiB','ZiB','YiB'];
  let u = -1;
  do {
      bytes /= thresh;
      ++u;
  } while (Math.abs(bytes) >= thresh && u < units.length - 1)

  return bytes.toFixed(1) + ' ' + units[u];
}

export function range(start: number, end: number) {
  const length = end - start
  return Array.from({ length }, (_, i) => start + i)
}

export function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

export function getCookie(name: string) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts?.pop()?.split(';')?.shift()
}

export { request, alertDialog, isMobileNumber, camelizeKeys, asyncDebounce, normValidDomSelector, isEmail, camelCase, confirm, atom}

import * as React from "react";

function SvgTensorflow(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      className="tensorflow_svg__icon"
      viewBox="0 0 1024 1024"
      xmlns="http://www.w3.org/2000/svg"
      width={200}
      height={200}
      {...props}
    >
      <defs>
        <style />
      </defs>
      <path d="M836.267 512l4.266 200.533-132.266-76.8V921.6L533.333 1024V0l435.2 251.733v226.134l-260.266-153.6v115.2zm-780.8-260.267L490.667 0v1024L315.733 921.6V324.267l-260.266 153.6z" />
    </svg>
  );
}

export default SvgTensorflow;

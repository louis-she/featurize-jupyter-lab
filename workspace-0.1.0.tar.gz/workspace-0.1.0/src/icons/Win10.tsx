import * as React from "react";

function SvgWin10(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" {...props}>
      <path fill="#90c300" d="M242.526 40.421L512 0v239.832H242.526z" />
      <path fill="#f8672c" d="M0 75.453l206.596-30.541v197.614H0z" />
      <path fill="#ffc400" d="M242.526 471.579L512 512V278.456H242.526z" />
      <path fill="#00b4f2" d="M0 436.547l206.596 30.541V278.456H0z" />
    </svg>
  );
}

export default SvgWin10;

import * as React from "react";

function SvgInventory(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M19.444 3.6H5.36c-.88 0-1.76.792-1.76 1.76v2.65c0 .634.378 1.18.88 1.487v9.947c0 .968.968 1.76 1.76 1.76h12.323c.793 0 1.76-.792 1.76-1.76V9.497c.503-.308.881-.853.881-1.487V5.36c0-.968-.88-1.76-1.76-1.76zm-.88 15.844H6.24V9.76h12.322v9.683zM19.443 8H5.36v-2.64h14.084V8z"
        fill="#6B6A6D"
      />
      <path d="M15.042 12.402h-5.28v1.76h5.28v-1.76z" fill="#6B6A6D" />
    </svg>
  );
}

export default SvgInventory;

import * as React from "react";

function SvgAlipay(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      className="alipay_svg__icon"
      viewBox="0 0 1024 1024"
      xmlns="http://www.w3.org/2000/svg"
      width={200}
      height={200}
      {...props}
    >
      <defs>
        <style />
      </defs>
      <path d="M214.4 780.8C387.2 819.2 499.2 745.6 576 656c6.4 6.4 9.6 6.4 16 6.4 54.4 28.8 310.4 150.4 310.4 150.4v-144c-38.4 0-179.2-48-281.6-83.2 54.4-96 73.6-188.8 73.6-188.8H515.2v-67.2h211.2v-32H515.2V195.2h-96v102.4H224v28.8h192v67.2H252.8v28.8h332.8c0 6.4 0 6.4-6.4 9.6 0 35.2-25.6 83.2-44.8 121.6-246.4-96-320-38.4-339.2-28.8-160 115.2-3.2 262.4 19.2 256zm-12.8-211.2c121.6-38.4 227.2 6.4 304 44.8-6.4 9.6-9.6 16-9.6 16C374.4 784 230.4 736 204.8 726.4c-57.6-19.2-76.8-124.8-3.2-156.8z" />
    </svg>
  );
}

export default SvgAlipay;

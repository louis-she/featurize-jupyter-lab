import * as React from "react";

function SvgBannerOld(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={942}
      height={568}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <circle opacity={0.5} cx={471} cy={885} r={471} fill="#B294FE" />
      <path
        opacity={0.2}
        fillRule="evenodd"
        clipRule="evenodd"
        d="M471 560c138.623 0 251-112.377 251-251S609.623 58 471 58 220 170.377 220 309s112.377 251 251 251zm0-46.639c112.866 0 204.361-91.495 204.361-204.361 0-112.866-91.495-204.361-204.361-204.361-112.866 0-204.361 91.495-204.361 204.361 0 112.866 91.495 204.361 204.361 204.361z"
        fill="#B294FE"
      />
      <path
        opacity={0.2}
        fillRule="evenodd"
        clipRule="evenodd"
        d="M471 560c138.623 0 251-112.377 251-251S609.623 58 471 58 220 170.377 220 309s112.377 251 251 251zm0-46.639c112.866 0 204.361-91.495 204.361-204.361 0-112.866-91.495-204.361-204.361-204.361-112.866 0-204.361 91.495-204.361 204.361 0 112.866 91.495 204.361 204.361 204.361z"
        fill="url(#banner_old_svg__paint0_linear)"
      />
      <g opacity={0.5} filter="url(#banner_old_svg__filter0_dd)">
        <path
          d="M512 325a4 4 0 014-4h180a4 4 0 014 4v269a4 4 0 01-4 4H516a4 4 0 01-4-4V325z"
          fill="#fff"
        />
        <path
          d="M512 325a4 4 0 014-4h180a4 4 0 014 4v269a4 4 0 01-4 4H516a4 4 0 01-4-4V325z"
          fill="url(#banner_old_svg__paint0_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.2} filter="url(#banner_old_svg__filter1_dd)">
        <path
          d="M486 287.126c0-2.831 2.372-5.126 5.298-5.126h238.404c2.926 0 5.298 2.295 5.298 5.126v344.748c0 2.831-2.372 5.126-5.298 5.126H491.298c-2.926 0-5.298-2.295-5.298-5.126V287.126z"
          fill="#fff"
        />
        <path
          d="M486 287.126c0-2.831 2.372-5.126 5.298-5.126h238.404c2.926 0 5.298 2.295 5.298 5.126v344.748c0 2.831-2.372 5.126-5.298 5.126H491.298c-2.926 0-5.298-2.295-5.298-5.126V287.126z"
          fill="url(#banner_old_svg__paint1_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.6} filter="url(#banner_old_svg__filter2_dd)">
        <rect
          x={273}
          y={321}
          width={25}
          height={254}
          rx={12.5}
          fill="#FDEEC7"
        />
        <rect
          x={273}
          y={321}
          width={25}
          height={254}
          rx={12.5}
          fill="url(#banner_old_svg__paint2_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.3} filter="url(#banner_old_svg__filter3_dd)">
        <rect
          x={229}
          y={377}
          width={25}
          height={198}
          rx={12.5}
          fill="#D3DAFF"
        />
        <rect
          x={229}
          y={377}
          width={25}
          height={198}
          rx={12.5}
          fill="url(#banner_old_svg__paint3_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.6} filter="url(#banner_old_svg__filter4_dd)">
        <rect
          x={185}
          y={433}
          width={25}
          height={198}
          rx={12.5}
          fill="#FDEEC7"
        />
        <rect
          x={185}
          y={433}
          width={25}
          height={198}
          rx={12.5}
          fill="url(#banner_old_svg__paint4_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.3} filter="url(#banner_old_svg__filter5_dd)">
        <rect
          x={141}
          y={409}
          width={25}
          height={198}
          rx={12.5}
          fill="#D3DAFF"
        />
        <rect
          x={141}
          y={409}
          width={25}
          height={198}
          rx={12.5}
          fill="url(#banner_old_svg__paint5_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.6} filter="url(#banner_old_svg__filter6_dd)">
        <rect x={97} y={515} width={25} height={198} rx={12.5} fill="#FDEEC7" />
        <rect
          x={97}
          y={515}
          width={25}
          height={198}
          rx={12.5}
          fill="url(#banner_old_svg__paint6_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.4} filter="url(#banner_old_svg__filter7_dd)">
        <rect x={53} y={535} width={25} height={198} rx={12.5} fill="#D3DAFF" />
        <rect
          x={53}
          y={535}
          width={25}
          height={198}
          rx={12.5}
          fill="url(#banner_old_svg__paint7_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g opacity={0.5} filter="url(#banner_old_svg__filter8_dd)">
        <rect x={484} y={129} width={188} height={277} rx={86} fill="#fff" />
        <rect
          x={484}
          y={129}
          width={188}
          height={277}
          rx={86}
          fill="url(#banner_old_svg__paint8_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g filter="url(#banner_old_svg__filter9_dd)">
        <path
          d="M314 233c0-6.627 5.373-12 12-12h249c6.627 0 12 5.373 12 12v353c0 6.627-5.373 12-12 12H326c-6.627 0-12-5.373-12-12V233z"
          fill="#C3CCFE"
        />
        <path
          d="M314 233c0-6.627 5.373-12 12-12h249c6.627 0 12 5.373 12 12v353c0 6.627-5.373 12-12 12H326c-6.627 0-12-5.373-12-12V233z"
          fill="url(#banner_old_svg__paint9_linear)"
          fillOpacity={0.2}
        />
      </g>
      <g
        className="banner_old_svg__growwidth_221"
        filter="url(#banner_old_svg__filter10_dd)"
      >
        <rect x={340} y={282} width={221} height={17} rx={8.5} fill="#fff" />
      </g>
      <g
        className="banner_old_svg__growwidth_205"
        filter="url(#banner_old_svg__filter11_dd)"
      >
        <rect x={340} y={317} width={205} height={17} rx={8.5} fill="#EEE5FF" />
      </g>
      <g
        className="banner_old_svg__growwidth_130"
        filter="url(#banner_old_svg__filter12_dd)"
      >
        <rect x={340} y={352} width={130} height={17} rx={8.5} fill="#EEE5FF" />
      </g>
      <g
        className="banner_old_svg__growwidth_154"
        filter="url(#banner_old_svg__filter13_dd)"
      >
        <rect x={340} y={422} width={154} height={17} rx={8.5} fill="#fff" />
      </g>
      <g
        className="banner_old_svg__growwidth_91"
        filter="url(#banner_old_svg__filter14_dd)"
      >
        <rect x={340} y={457} width={91} height={17} rx={8.5} fill="#EEE5FF" />
      </g>
      <g
        className="banner_old_svg__growwidth_70"
        filter="url(#banner_old_svg__filter15_dd)"
      >
        <rect x={340} y={497} width={70} height={17} rx={8.5} fill="#EEE5FF" />
      </g>
      <g
        className="banner_old_svg__growwidth_139"
        filter="url(#banner_old_svg__filter16_dd)"
      >
        <rect x={340} y={532} width={139} height={17} rx={8.5} fill="#EEE5FF" />
      </g>
      <g
        className="banner_old_svg__udshake"
        opacity={0.6}
        filter="url(#banner_old_svg__filter17_dd)"
      >
        <path fill="#FFE1A8" d="M652 72h58v60h-58z" />
        <path
          fill="url(#banner_old_svg__paint10_linear)"
          fillOpacity={0.2}
          d="M652 72h58v60h-58z"
        />
      </g>
      <g
        className="banner_old_svg__udshake"
        opacity={0.1}
        filter="url(#banner_old_svg__filter18_dd)"
      >
        <path fill="#FFE1A8" d="M638 58h86v88h-86z" />
        <path
          fill="url(#banner_old_svg__paint11_linear)"
          fillOpacity={0.2}
          d="M638 58h86v88h-86z"
        />
      </g>
      <g
        className="banner_old_svg__udshake"
        opacity={0.1}
        filter="url(#banner_old_svg__filter19_dd)"
      >
        <path fill="#FFE1A8" d="M612 32h98v100h-98z" />
        <path
          fill="url(#banner_old_svg__paint12_linear)"
          fillOpacity={0.2}
          d="M612 32h98v100h-98z"
        />
      </g>
      <g
        className="banner_old_svg__udshake"
        opacity={0.6}
        filter="url(#banner_old_svg__filter20_dd)"
      >
        <path fill="#E8EBFF" d="M691 112h38v40h-38z" />
        <path
          fill="url(#banner_old_svg__paint13_linear)"
          fillOpacity={0.2}
          d="M691 112h38v40h-38z"
        />
      </g>
      <g
        className="banner_old_svg__lrshake"
        filter="url(#banner_old_svg__filter21_dd)"
      >
        <path fill="#D3DAFF" d="M265 410h80v84h-80z" />
        <path
          fill="url(#banner_old_svg__paint14_linear)"
          fillOpacity={0.2}
          d="M265 410h80v84h-80z"
        />
      </g>
      <g
        className="banner_old_svg__lrshake"
        opacity={0.3}
        filter="url(#banner_old_svg__filter22_dd)"
      >
        <path fill="#D3DAFF" d="M242 386h126v132H242z" />
        <path
          fill="url(#banner_old_svg__paint15_linear)"
          fillOpacity={0.2}
          d="M242 386h126v132H242z"
        />
      </g>
      <g
        className="banner_old_svg__lrshake"
        opacity={0.5}
        filter="url(#banner_old_svg__filter23_dd)"
      >
        <path fill="#FFEEDA" d="M281 427h48v50h-48z" />
        <path
          fill="url(#banner_old_svg__paint16_linear)"
          fillOpacity={0.2}
          d="M281 427h48v50h-48z"
        />
      </g>
      <g filter="url(#banner_old_svg__filter24_dd)">
        <rect x={386} y={193} width={130} height={45} rx={12} fill="#fff" />
        <rect
          x={386}
          y={193}
          width={130}
          height={45}
          rx={12}
          fill="url(#banner_old_svg__paint17_linear)"
          fillOpacity={0.2}
        />
      </g>
      <defs>
        <filter
          id="banner_old_svg__filter0_dd"
          x={477}
          y={289}
          width={268}
          height={357}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.32 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={20} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.4 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter1_dd"
          x={451}
          y={250}
          width={329}
          height={435}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.32 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={20} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.4 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter2_dd"
          x={238}
          y={289}
          width={105}
          height={334}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter3_dd"
          x={194}
          y={345}
          width={105}
          height={278}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter4_dd"
          x={150}
          y={401}
          width={105}
          height={278}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter5_dd"
          x={106}
          y={377}
          width={105}
          height={278}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter6_dd"
          x={62}
          y={483}
          width={105}
          height={278}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter7_dd"
          x={18}
          y={503}
          width={105}
          height={278}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter8_dd"
          x={449}
          y={97}
          width={268}
          height={357}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.32 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={20} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.4 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter9_dd"
          x={279}
          y={189}
          width={353}
          height={457}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.32 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={20} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.4 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter10_dd"
          x={313}
          y={258}
          width={285}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter11_dd"
          x={313}
          y={293}
          width={269}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter12_dd"
          x={313}
          y={328}
          width={194}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter13_dd"
          x={313}
          y={398}
          width={218}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter14_dd"
          x={313}
          y={433}
          width={155}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter15_dd"
          x={313}
          y={473}
          width={134}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter16_dd"
          x={313}
          y={508}
          width={203}
          height={81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={16} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={6} />
          <feGaussianBlur stdDeviation={6} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter17_dd"
          x={617}
          y={40}
          width={138}
          height={140}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter18_dd"
          x={603}
          y={26}
          width={166}
          height={168}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter19_dd"
          x={577}
          y={0}
          width={178}
          height={180}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter20_dd"
          x={656}
          y={80}
          width={118}
          height={120}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter21_dd"
          x={230}
          y={378}
          width={160}
          height={164}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter22_dd"
          x={207}
          y={354}
          width={206}
          height={212}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter23_dd"
          x={246}
          y={395}
          width={128}
          height={130}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.34 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <filter
          id="banner_old_svg__filter24_dd"
          x={351}
          y={161}
          width={210}
          height={125}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={5} dy={8} />
          <feGaussianBlur stdDeviation={20} />
          <feColorMatrix values="0 0 0 0 0.20098 0 0 0 0 0.20098 0 0 0 0 0.803922 0 0 0 0.04 0" />
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow" />
          <feColorMatrix
            in="SourceAlpha"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx={4} dy={12} />
          <feGaussianBlur stdDeviation={9} />
          <feColorMatrix values="0 0 0 0 0.401961 0 0 0 0 0.401961 0 0 0 0 0.803922 0 0 0 0.12 0" />
          <feBlend in2="effect1_dropShadow" result="effect2_dropShadow" />
          <feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape" />
        </filter>
        <linearGradient
          id="banner_old_svg__paint0_linear"
          x1={716}
          y1={414}
          x2={716}
          y2={515}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint1_linear"
          x1={756.192}
          y1={401.188}
          x2={756.192}
          y2={530.628}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint2_linear"
          x1={285.5}
          y1={321}
          x2={285.5}
          y2={575}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint3_linear"
          x1={241.5}
          y1={377}
          x2={241.5}
          y2={575}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint4_linear"
          x1={197.5}
          y1={433}
          x2={197.5}
          y2={631}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint5_linear"
          x1={153.5}
          y1={409}
          x2={153.5}
          y2={607}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint6_linear"
          x1={109.5}
          y1={515}
          x2={109.5}
          y2={713}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint7_linear"
          x1={65.5}
          y1={535}
          x2={65.5}
          y2={733}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint8_linear"
          x1={578}
          y1={129}
          x2={578}
          y2={406}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint9_linear"
          x1={450.5}
          y1={221}
          x2={450.5}
          y2={598}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint10_linear"
          x1={681}
          y1={72}
          x2={681}
          y2={132}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint11_linear"
          x1={681}
          y1={58}
          x2={681}
          y2={146}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint12_linear"
          x1={661}
          y1={32}
          x2={661}
          y2={132}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint13_linear"
          x1={710}
          y1={112}
          x2={710}
          y2={152}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint14_linear"
          x1={305}
          y1={410}
          x2={305}
          y2={494}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint15_linear"
          x1={305}
          y1={386}
          x2={305}
          y2={518}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint16_linear"
          x1={305}
          y1={427}
          x2={305}
          y2={477}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
        <linearGradient
          id="banner_old_svg__paint17_linear"
          x1={451}
          y1={193}
          x2={451}
          y2={238}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopOpacity={0} />
          <stop offset={0} stopColor="#fff" stopOpacity={0} />
          <stop offset={1} stopColor="#C3CCFE" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export default SvgBannerOld;

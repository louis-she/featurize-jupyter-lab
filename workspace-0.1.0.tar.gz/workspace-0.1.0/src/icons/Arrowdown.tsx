import * as React from "react";

function SvgArrowdown(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M5.833 8.333L10 12.5l4.167-4.167H5.833z" />
    </svg>
  );
}

export default SvgArrowdown;

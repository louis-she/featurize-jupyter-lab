import * as React from "react";

function SvgWindows(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={24}
      height={24}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M3 2a2 2 0 00-2 2v12a2 2 0 002 2h7v2H8v2h8v-2h-2v-2h7a2 2 0 002-2V4a2 2 0 00-2-2H3zm0 2h18v12H3V4zm14 1l-4 .445V9h4V5zm-6 .793l-4 .445V9h4V5.793zM7 11v2.762l4 .445V11H7zm6 0v3.555L17 15v-4h-4z"
        fill="#6B6A6D"
      />
    </svg>
  );
}

export default SvgWindows;

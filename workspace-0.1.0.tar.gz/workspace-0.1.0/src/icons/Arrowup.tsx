import * as React from "react";

function SvgArrowup(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M11.333 9.333L8 6 4.667 9.333h6.666z" opacity={0.5} />
    </svg>
  );
}

export default SvgArrowup;

import * as React from "react";

function SvgPycharm(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70" {...props}>
      <linearGradient
        id="pycharm_svg__a"
        gradientUnits="userSpaceOnUse"
        x1={24.998}
        y1={27.046}
        x2={66.656}
        y2={27.046}
      >
        <stop offset={0} stopColor="#21d789" />
        <stop offset={1} stopColor="#07c3f2" />
      </linearGradient>
      <path
        fill="url(#pycharm_svg__a)"
        d="M49.1 11l20.4 17.1L62.2 43l-12.4-3.4H39.2z"
      />
      <linearGradient
        id="pycharm_svg__b"
        gradientUnits="userSpaceOnUse"
        x1={-24.559}
        y1={59.081}
        x2={61.22}
        y2={-4.241}
      >
        <stop offset={0.011} stopColor="#fcf84a" />
        <stop offset={0.112} stopColor="#a7eb62" />
        <stop offset={0.206} stopColor="#5fe077" />
        <stop offset={0.273} stopColor="#32da84" />
        <stop offset={0.306} stopColor="#21d789" />
        <stop offset={0.577} stopColor="#21d789" />
        <stop offset={0.597} stopColor="#21d789" />
        <stop offset={0.686} stopColor="#20d68c" />
        <stop offset={0.763} stopColor="#1ed497" />
        <stop offset={0.835} stopColor="#19d1a9" />
        <stop offset={0.904} stopColor="#13ccc2" />
        <stop offset={0.971} stopColor="#0bc6e1" />
        <stop offset={1} stopColor="#07c3f2" />
      </linearGradient>
      <path
        fill="url(#pycharm_svg__b)"
        d="M28.5 22.1l-4 20.9-.4 7.2-9.9 4.3L0 56l4.3-45.3L29.9 0l15.8 10.4z"
      />
      <linearGradient
        id="pycharm_svg__c"
        gradientUnits="userSpaceOnUse"
        x1={9.33}
        y1={77.654}
        x2={23.637}
        y2={32.76}
      >
        <stop offset={0} stopColor="#21d789" />
        <stop offset={0.164} stopColor="#24d788" />
        <stop offset={0.305} stopColor="#2fd886" />
        <stop offset={0.437} stopColor="#41da82" />
        <stop offset={0.564} stopColor="#5adc7d" />
        <stop offset={0.688} stopColor="#7ae077" />
        <stop offset={0.809} stopColor="#a1e36e" />
        <stop offset={0.925} stopColor="#cfe865" />
        <stop offset={1} stopColor="#f1eb5e" />
      </linearGradient>
      <path
        fill="url(#pycharm_svg__c)"
        d="M28.5 22.1l1.9 40.4L24 70 0 56l19.7-29.4z"
      />
      <linearGradient
        id="pycharm_svg__d"
        gradientUnits="userSpaceOnUse"
        x1={28.275}
        y1={38.623}
        x2={59.409}
        y2={-3.236}
      >
        <stop offset={0} stopColor="#21d789" />
        <stop offset={0.061} stopColor="#24d788" />
        <stop offset={0.113} stopColor="#2fd886" />
        <stop offset={0.162} stopColor="#41da82" />
        <stop offset={0.209} stopColor="#5add7d" />
        <stop offset={0.255} stopColor="#79e077" />
        <stop offset={0.258} stopColor="#7ce076" />
        <stop offset={0.499} stopColor="#8ce173" />
        <stop offset={0.925} stopColor="#b2e56b" />
      </linearGradient>
      <path fill="url(#pycharm_svg__d)" d="M54.9 19.1H30.6L52.1 0z" />
      <linearGradient
        id="pycharm_svg__e"
        gradientUnits="userSpaceOnUse"
        x1={75.889}
        y1={43.95}
        x2={13.158}
        y2={43.369}
      >
        <stop offset={0.387} stopColor="#fcf84a" />
        <stop offset={0.536} stopColor="#ecf451" />
        <stop offset={0.826} stopColor="#c2e964" />
        <stop offset={0.925} stopColor="#b2e56b" />
      </linearGradient>
      <path
        fill="url(#pycharm_svg__e)"
        d="M70 62.6l-21.4 7.3-28.4-8 8.3-39.8 3.3-3 17.3-1.6-1.6 17.4 13.8-5.3z"
      />
      <g>
        <path d="M13.4 13.4h43.2v43.2H13.4z" />
        <path
          fill="#fff"
          d="M17.5 48.5h16.2v2.7H17.5zM17.3 19.1h7.3c4.3 0 6.9 2.5 6.9 6.2v.1c0 4.1-3.2 6.3-7.2 6.3h-3V37h-3.9V19.1zm7.1 9c2 0 3.1-1.2 3.1-2.7v-.1c0-1.8-1.2-2.7-3.2-2.7h-3v5.5h3.1zM33.1 28.1c0-5.1 3.8-9.3 9.3-9.3 3.4 0 5.4 1.1 7.1 2.8L47 24.5c-1.4-1.3-2.8-2-4.6-2-3 0-5.2 2.5-5.2 5.6V28c0 3.1 2.1 5.6 5.2 5.6 2 0 3.3-.8 4.7-2.1l2.5 2.5c-1.8 2-3.9 3.2-7.3 3.2-5.3.1-9.2-4-9.2-9.1"
        />
      </g>
    </svg>
  );
}

export default SvgPycharm;

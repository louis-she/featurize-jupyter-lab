import * as React from "react";

function SvgAlarm(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={20}
      height={20}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M18.333 4.767L14.5 1.55l-1.075 1.275 3.833 3.217 1.075-1.275zM6.567 2.825L5.5 1.55 1.667 4.758l1.075 1.275 3.825-3.208zm3.85 3.842h-1.25v5l3.958 2.375.625-1.025-3.333-1.975V6.667zM10 3.333a7.5 7.5 0 00-7.5 7.5c0 4.142 3.35 7.5 7.5 7.5a7.5 7.5 0 000-15zm0 13.334a5.829 5.829 0 01-5.833-5.834A5.83 5.83 0 0110 5a5.829 5.829 0 015.833 5.833A5.829 5.829 0 0110 16.667z"
        fill="#fff"
      />
    </svg>
  );
}

export default SvgAlarm;

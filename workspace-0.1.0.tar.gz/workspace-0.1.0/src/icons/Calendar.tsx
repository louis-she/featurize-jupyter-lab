import * as React from "react";

function SvgCalendar(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path d="M16.667 2.5h-.834V.833h-1.666V2.5H5.833V.833H4.167V2.5h-.834c-.916 0-1.666.75-1.666 1.667V17.5c0 .917.75 1.667 1.666 1.667h13.334c.916 0 1.666-.75 1.666-1.667V4.167c0-.917-.75-1.667-1.666-1.667zm0 15H3.333V6.667h13.334V17.5z" />
    </svg>
  );
}

export default SvgCalendar;

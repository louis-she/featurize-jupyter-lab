export type IStatus = 'online' | 'offline' | 'invalid' | 'busy' | 'disabled' | 'pending'
export type VirtualMachineStatus = 'start_pending' | 'online' | 'end_pending' | 'shutdown' | 'archived' | 'invalid'

export interface IBase {
  id: string;
  created: Date;
}

export interface IAgent extends IBase{
  user_id: string;
  name: string;
  status: IStatus;
  startedAt?: Date;
  totalServedTime: Date
  spawningServersNum: number;
  nodeId: string;
  instance: IInstance;
  wizardStep: number;
  token?: string;
  hardwareInfo: {
    system?: string;
    cpu?: number;
    memory?: number;
    disk?: number;
    diskType?: string;
    gpus?: string[];
    cpuModel?: string;
  };
}

export interface LongTermPlan {
  name: string;
  days: number;
  amount: number;
}

export interface IInstance extends IBase {
  userId: string;
  agentId: string;
  name: string;
  description: string;
  status: IStatus;
  startedAt: Date;
  totalServedTime: number;
  cpu: number;
  memory: number;
  disk: number;
  diskType: string;
  gpu: string;
  period: any;
  hardware: string;
  url: string;
  occupiedUserId: string;
  occupiedUser: IUser;
  unitPrice: number;
  host: IUser;
  enabled: boolean;
  nextStartTime?: Date | string;
  nextEndTime?: Date | string;
  hostEarnedBilling?: number;
  agent?: IAgent;
  lastRequestedAt?: Date;
  reviewReduced: number;
  cover?: string;
  ltps: LongTermPlan[];
  ltOccupied: boolean;
  ltTracker?: ILtTracker;
  sshPort?: string;
  region?: string;
}

export interface IUser extends IBase {
  kind: string;
  name: string;
  admin: boolean;
  avatar: string;
  phoneNumber: string;
  mail: string;
  groups: any[];
  server: any[];
  verified: boolean;
  pending: boolean;
  created: Date;
  last_activity: Date;
  servers: any[];
  withdrawableBalance: number;
  nonWithdrawableBalance: number;
  enabledTwoFactorAuthentication: boolean;
  host: boolean;
  tfaPending: boolean;
  timezone: string;
  metas: any;
  discount: number;
  weeklyHours: number;
  cloudMigratingStatus: number;
  sshPwd: string;
  gray: boolean;
  wechatUnionid: string;
  bio: string;
  category: string;
  institution: string;
  place: string;
  kaggle: string;
  kaggleVerified: boolean;
  github: string;
  githubVerified: boolean;
  hasPaied: boolean;
  cloudUsage: number;
  cloudQuota: number;
  level: number;
  cover: string;
  meowtronEnabled: boolean;
}

export interface IOrder extends IBase {
  userId: string;
  hostId: string;
  instanceId: string;
  created: Date;
  amount: number;
  totalSeconds: number;
  userReview: number;
  host: IUser;
  instance: IInstance;
  review: IReview | null;
}

export interface IReview extends IBase {
  reviewerId: string;
  reviewableId: string;
  reviewableType: string;
  comment: string | null;
  rate: number | null;
}

export interface INotification extends IBase {
  userId: string;
  title: string;
  content: string;
  unread: boolean;
  url: string;
  level: string;
  sendRangeStart: string;
  sendDialog: string;
}

export interface IEvent extends IBase {
  eventableId: string;
  eventableType: string;
  icon: string;
  title: string;
  description: string;
  created: Date;
  status: IStatus;
}

export interface ITransaction extends IBase {
  platform: string;
  amount: number;
  status: string;
}

export interface IDataset extends IBase {
  uploaderId: string;
  name: string;
  description: string;
  cover: string;
  range: 'public' | 'group' | 'personal';
  tag: string;
  tags: ITag[];
  size: number;
  md5: string;
  url: string;
  usedCount: number;
  checkpoint: any;
  uploaded: boolean;
  signature: string;
  progress: number;
  domain: string;
  path: string;
  uploader?: IUser;
  filename: string;
  abstract: string;
  cacheProgress: number;
  datasetCenter: {
    innerIp: string;
    bucket: string;
    name: string;
  }
}

export interface IImage extends IBase {
  name: string;
  tag: string;
  digest: string;
  description: string;
  extraSize: number;
  creatorId: string;
  creator: IUser;
}

export interface IPublishNotebook extends IBase {
  digest: string;
  user: IUser;
  url: string;
  created: Date;
  updated: Date;
  content: string;
}

export interface IComment extends IBase {
  user: IUser;
  content: string;
  created: Date;
  likesNum: number;
  liked: Boolean;
}

export interface ILtTracker extends IBase {
  requestedAt: Date;
  shouldEndAt: Date;
  autoReturn: boolean;
}

export interface IActivity extends IBase {
  title: string;
  description: string;
  status: string;
  bonus: string;
  shouldEndAt: Date | null;
  type: string;
  state: any;
}

export interface INotebookVersion extends IBase {
  content: string
  datasetIds: string
  versionNum: number
  current: boolean
}

export interface INotebook extends IBase {
  user: IUser
  name: string
  digest: string
  lang: string
  cover: string
  withinFeaturize: boolean
  settings: any
  version: INotebookVersion
  viewCount: number
  wechatThumbUrl: string
  abstract: string
  tags: ITag[]
}

export interface ITag extends IBase {
  name: string
  icon: string
  color: string
  resource: string
  category: string
}

export interface IConsumption extends IBase {
  userId: string;
  resourceId: string;
  resourceType: string;
  couponAmount: number;
  balanceAmount: number;
  totalAmount: number;
  remark: string;
}

export interface ICoupon extends IBase {
  userId: string;
  resourceId: string;
  resourceType: string;
  couponAmount: number;
  balanceAmount: number;
  remark: string;
}

export enum InvoiceEnum {
  pending = "pending",
  freezed = "freezed",
  completed = "completed"
}

export interface IInvoice extends IBase {
  id: string
  mail: string
  title: string
  userId: string
  amount: number
  sourceCategory: string
  creditNumber: string
  category: string
  bankPlace: string
  bankAccount: string
  registerPlace: string
  registerPhoneNumber: string
  remark: string
  status: InvoiceEnum
}

export interface IDisk {
  mountPoint: string
  size: number
}

export interface IHostMachine extends IBase {
  ltps: LongTermPlan[]
  gpuType: string
  gpuMemory: number
  gpuCount: number
  memory: number
  cpuType: string
  cpuCount: number
  disk: IDisk[]
  theme: string

  unitCpuCount: number
  unitMemory: number
  unitDisk: number

  availableGpuCount: number
  availableMemory: number
  availableCpuCount: number
  availableDisk: IDisk[]
  availableUnitCount: number

  unitPrice: number
}

export interface IBillingTracker extends IBase {
  userId: string
  resourceId: string
  resourceType: string
  billingType: string
  unitPrice: number
  lastCheckedTimestamp: number
  status: number
  amount: number
  couponAmount: number
  balanceAmount: number
  autoSwitch: boolean
  duedAt: Date,
  settledAt: Date
}

export interface IVirtualMachine extends IBase {
  hostId: string
  userId: string
  status: VirtualMachineStatus
  internalIp: string
  host: IHostMachine
  tracker: IBillingTracker
  imageId: string
  image: IImage

  gpuType: string
  gpuMemory: number
  gpuCount: number
  memory: number
  cpuType: number
  cpuCount: number
  disk: number
  featurizePassword: string
  sshPort: string
}

export interface IImage {
  key: string
  name: string
  desc?: string
  libs: {
    icon: string
    name: string
    version: string
  }[]
}

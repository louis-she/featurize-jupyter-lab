import { JupyterFrontEnd, } from '@jupyterlab/application';
import { ReactWidget } from '@jupyterlab/apputils'
import React, { useEffect, useState } from 'react';
import SmartDisplayIcon  from '../icons/SmartDisplay'
import style from "./index.module.scss"
import { subscribe, storage } from '../storage';
import moment from 'moment';
import SvgSchedule from '../icons/Schedule';
import clsx from 'clsx';
import OverlayTrigger from '../components/overlay-trigger';
import Empty from '../components/empty';
import { Download, Folder } from '../icons';
import ProgressBar from '../components/progress-bar';
import { requestLab } from '../helper';
import { IBillingTracker } from '../types';

interface ITask {
  id: number
  icon: React.ReactElement | string
  name: string
  progress?: number
  status: 'waiting' | 'inprogress' | 'success' | 'error' | 'canceled'
  errorMessage?: string
  onChecked: any
  desc?: string
}

const taskIconMapping : any = {
  'download': <Download />,
  'folder': <Folder />,
}

const BottomStatusComponent = () => {

  const [timeBilling, setTimeBilling] = useState<IBillingTracker | null>(storage.vm.tracker)
  const [tasks, setTasks] = useState<ITask[]>([])
  const [showTask, setShowTask] = useState<boolean>(false)

  useEffect(() => {
    subscribe('BILLING_TRACKER_UPDATE', (payload: IBillingTracker) => {
      setTimeBilling(payload)
    })

    subscribe('TASK_UPDATED', (payload: ITask) => {
      updateTask(payload)
    })
  }, [])

  const updateTask = (newTask: ITask) => {
    setTasks(([...tasks]) => {
      const index = tasks.findIndex((task) => task.id === newTask.id)
      if (index !== -1) {
        tasks[index] = newTask
      } else {
        setShowTask(true)
        tasks.push(newTask)
      }
      return tasks
    })
  }

  useEffect(() => {
  }, [])

  const handleTerminateTask = (pid: number) => async () => {
    await requestLab({
      path: '/featurize/terminate',
      method: 'post',
      data: { pid }
    })
  }

  const handleHideTask = (id: number) => () => {
    setTasks(([...tasks]) =>
      tasks.filter((task) => task.id !== id)
    )
  }

  return (
    <div className={style.root}>
      <div className={style.item}>
        <SvgSchedule />
        {timeBilling ?
          <>
          {timeBilling.duedAt ?
            `${moment(timeBilling.duedAt).fromNow()}到期`
            :
            `已运行 ${moment.duration(moment().diff(moment(timeBilling.created), "seconds"), "seconds").asHours().toFixed(1)} 小时`
          }
          </>
          :
          "正在加载"
        }
      </div>
      <OverlayTrigger
        placement="top"
        show={showTask}
        onShow={() => setShowTask(true)}
        onHide={() => setShowTask(false)}
        overlay={
          <div className={clsx(style.tasks, {[style.empty]: tasks.length === 0})}>
            {tasks.length === 0 &&
              <Empty label="没有正在进行的任务" />
            }
            {tasks.map((task: ITask) =>
              <div className={clsx(style.task, style[task.status])}>
                <div className={style.taskLeft}>
                  {taskIconMapping[task.icon as any]}
                </div>
                <div className={style.taskRight}>
                  <div className={style.taskHead}>
                    <div className={style.taskName}>
                      {task.name}
                    </div>
                    <div className={style.taskOperations}>
                      {task.status === "inprogress" &&
                        <a className={style.terminateBtn} onClick={handleTerminateTask(task.id)}>终止</a>
                      }
                      {task.status !== "inprogress" &&
                        <a className={style.canceled} onClick={handleHideTask(task.id)}>不再显示</a>
                      }
                    </div>
                  </div>
                  <div className={style.taskDesc}>
                    {task.desc}
                  </div>
                  {task.progress !== 0 ?
                    <>
                      {(task.status === 'inprogress' || task.status === 'success') &&
                        <ProgressBar className={style.taskProgress} percentage={task.progress} />
                      }
                      {task.status === "canceled" &&
                        <ProgressBar status="terminated" className={style.taskProgress} percentage={task.progress} text="已终止" />
                      }
                      {task.status === "error" &&
                        <ProgressBar status="terminated" className={style.taskProgress} percentage={task.progress} text="错误" />
                      }
                    </>
                    :
                    <></>
                  }
                </div>
              </div>
            )}
          </div>
        }
      >
        <div className={clsx(style.item, style.backgroundTasks)}>
          <SmartDisplayIcon />
          后台任务
          {tasks.length !== 0 &&
            <div className={style.taskReadDot}>
              {tasks.length}
            </div>
          }
        </div>
      </OverlayTrigger>
    </div>
  )
}

export class BottomStatus extends ReactWidget {
  constructor(app: JupyterFrontEnd) {
    super();
    this.addClass('featurize-bottom-status')
  }

  render(): JSX.Element {
    return <BottomStatusComponent />
  }
}
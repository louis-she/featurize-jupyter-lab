import os
import json
import tornado
from jupyter_server.auth.login import LoginHandler
from jupyter_server.auth.logout import LogoutHandler
from jupyterlab.labapp import LabApp


class FeaturizeLoginHandler(LoginHandler):

    @staticmethod
    def login_available(settings):
        return True

    async def _user_bus_status(self):
        # get user status
        client = tornado.httpclient.AsyncHTTPClient()
        try:
            response = await client.fetch(
                f'{os.getenv("BUS_INNER_ADDR")}/bus/api/v1/user_status',
                headers={'cookie': self.request.headers.get('cookie', '')}
            )
        except tornado.httpclient.HTTPClientError:
            raise tornado.web.HTTPError(401)

        data = json.loads(response.body.decode())
        self.log.info(f'server user status response with: {data}')
        return data['data']

    async def get(self):
        if self.current_user:
            next_url = self.get_argument('next', default=self.base_url)
            return self.redirect(next_url)
        # 检查用户是否在 bus 中登录，如果有，set cookie 然后跳转到 next_url
        # 如果没有，跳转到 bus 的登录页面
        user_status = await self._user_bus_status()
        self.log.info(f'instance uuid: {os.getenv("UUID")}, user status: {user_status}, klass {user_status.__class__.__name__}')
        if user_status and user_status.get('user_id') is not None and os.getenv('UUID') in user_status['instance_ids']:
            self.log.info('validate passed. redirect to workspace')
            self.set_login_cookie(self, user_id=user_status['user_id'])
            self.redirect(f'{self.base_url}lab')
        else:
            self.log.info('validate failed. redirect to bus signin page')
            self.redirect(f'{os.getenv("BUS_ADDR")}/signin?next={os.getenv("LAB_ADDR")}{self.base_url}lab')


class FeaturizeLogoutHandler(LogoutHandler):
    pass


class FeaturizeNotebookApp(LabApp):

    name = "workspace"

    login_handler_class = FeaturizeLoginHandler

    def _jupyter_server_config(self):
        base_config = super()._jupyter_server_config()
        base_config["ServerApp"]["login_handler_class"] = FeaturizeLoginHandler
        base_config["ServerApp"]["logout_handler_class"] = FeaturizeLogoutHandler

        return base_config

    @classmethod
    def launch_instance(cls, argv=None, **kwargs):
        return super().launch_instance(argv=argv, **kwargs)


main = launch_new_instance = FeaturizeNotebookApp.launch_instance

if __name__ == "__main__":
    main()

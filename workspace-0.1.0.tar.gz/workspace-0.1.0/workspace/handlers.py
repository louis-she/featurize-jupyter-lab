import json
import shutil
import sys

from jupyter_server.base.handlers import APIHandler
import tornado
import threading

import hmac
import json
import logging
import multiprocessing
import os
import time
import signal
from base64 import b64encode
from pathlib import Path
from urllib.parse import quote as urlquote
from sshpubkeys import SSHKey

import requests
import tornado
import asyncio
from websocket import create_connection

MODE = Path('/etc/mode.txt').read_text()
TOKEN = Path('/etc/featurize_token.txt').read_text()

if MODE == "development":
    BUSADDR = "bus.dev.featurize.cn"
elif MODE == "staging":
    BUSADDR = "staging.featurize.cn"
else:
    BUSADDR = "featurize.cn"

logger = logging.getLogger('featurize')
logger.setLevel(logging.INFO)

handler = logging.FileHandler(Path.home() / '.server.log')
handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)

_web_app = None


def task_test(period):
    logger.info("task test running")
    task = Task(icon='download', name='正在下载文件', status='inprogress', desc="瓷砖表面瑕疵质检 - ROUND1 - 测试")

    amount = 100 / period
    logger.info(os.getpid())
    for i in range(period):
        task.update(progress=i * amount)
        time.sleep(1)
    task.update(progress=100, status="success", name='数据集已下载')
    task.done()


def _main(target, args):
    try:
        logger.info(f"subprocess forked: {os.getpid()}")
        res = target(*args)
        if asyncio.iscoroutine(res):
            asyncio.run(res)
    except Exception as e:
        logger.exception(f"Uncaught exception {e}")


def _fork(target, args):
    process = multiprocessing.Process(target=_main, args=[target, args])
    process.start()
    process.join()
    logger.info(f"Process ext code: {process.exitcode}")


def async_child_process(target, args):
    thread = threading.Thread(target=_fork, args=[target, args])
    thread.start()


def _param_to_quoted_query(k, v):
    if v:
        return urlquote(k, '') + '=' + urlquote(v, '')
    else:
        return urlquote(k, '')


def extract(source, dest):
    out = os.system(f'unzip -o "{source}" -d "{dest}" >> ~/.server.log 2>&1 ')
    if out == 0:
        return 0

    out = os.system(f'tar -zxf "{source}" -C "{dest}" >> ~/.server.log 2>&1')
    if out == 0:
        return 0

    out = os.system(f'tar -xf "{source}" -C "{dest}" >> ~/.server.log 2>&1')

    out = os.system(f'7z x "{source}" -o"{dest}" >> ~/.server.log 2>&1')
    if out == 0 or out == 512:
        return 0

    return out


# from https://github.com/aliyun/aliyun-oss-python-sdk/blob/master/oss2/auth.py#L34
def sign_rtmp_url(access_id, secret, sts_token, domain, path, bucket_name='featurize-dataset-public', expires=600, params=None):
    expiration_time = int(time.time()) + expires

    canonicalized_resource = "/%s/%s?security-token=%s" % (bucket_name, path, sts_token)
    canonicalized_params = []

    if params:
        items = params.items()
        for k, v in items:
            if k != "OSSAccessKeyId" and k != "Signature" and k != "Expires" and k != "SecurityToken":
                canonicalized_params.append((k, v))

    canonicalized_params.sort(key=lambda e: e[0])

    p = params if params else {}
    string_to_sign = f"GET\n\n\n{expiration_time}\n{canonicalized_resource}"

    h = hmac.new(secret.encode(), string_to_sign.encode(), 'sha1')
    signature = b64encode(h.digest())

    p['OSSAccessKeyId'] = access_id
    p['Expires'] = str(expiration_time)
    p['Signature'] = signature
    p['security-token'] = sts_token

    return f"https://{domain}/{path}?{'&'.join(_param_to_quoted_query(k, v) for k, v in p.items())}"


def folder_size(dir):
    total = 0
    for entry in os.scandir(dir):
        if entry.is_file():
            total += entry.stat().st_size
        elif entry.is_dir():
            total += folder_size(entry.path)
    return total


class FeaturizeHandler(APIHandler):

    def write(self, data=None, message=None, code=None):
        if data is None:
            data = {}
        if code is None:
            code = 0
        if message is None:
            message = 'success' if code == 0 else 'error'

        super().write(json.dumps({
            'status': code,
            'data': data,
            'message': message
        }))

    @property
    def params(self):
        if hasattr(self, "_params"):
            return self._params

        body = self.get_json_body()
        self._params = self.path_kwargs
        self._params.update({k: self.get_argument(k) for k, v in self.request.arguments.items()})
        if body is not None:
            self._params.update(body)

        return self._params


class TokenHandler(FeaturizeHandler):

    def get(self):
        self.write(TOKEN)


class BusaddrHandler(FeaturizeHandler):

    def get(self):
        self.write(BUSADDR)


def to_camel_case(snake_str):
    components = snake_str.split('_')
    # We capitalize the first letter of each component except the first one
    # with the 'title' method and join them together.
    return components[0] + ''.join(x.title() for x in components[1:])


class Websocket:

    def __init__(self, url):
        self.url = url
        self.connect()

    def connect(self):
        self.ws = create_connection(self.url)

    def send(self, message):
        try:
            self.ws.send(message)
        except Exception as e:
            logger.error('Websocket send error, reconnecting')
            self.connect()
            self.ws.send(message)

    def close(self):
        self.ws.close()


class Task:

    def __init__(self, **props):
        url = f"wss://{BUSADDR}/bus/websocket/virtual_machine_publish?token={TOKEN}"
        self.ws = Websocket(url)
        self.props = {
            'id': os.getpid(),
            **props,
        }

        def signal_handler(sig, frame):
            self.update(status='canceled', desc='已取消')
            self.done()
            sys.exit(0)
        signal.signal(signal.SIGINT, signal_handler)
        self.update(progress=0)

    def update(self, **props):
        self.props.update(props)
        try:
            self.ws.send(json.dumps({
                'event': 'TASK_UPDATED',
                'payload': self.props
            }))
        except Exception as e:
            logger.exception(f"Websocket send error: {e}")

    def done(self):
        self.ws.close()


def download_dataset_main(dataset, credentials):
    task = Task(icon='download', name='正在下载数据集', progress=0, status='inprogress', desc=dataset['name'])
    chunk_size = 1024 * 1024 * 4
    dataset_dir = Path.home() / 'data'
    dataset_dir.mkdir(parents=True, exist_ok=True)
    dataset_file = dataset_dir / dataset['path'].split('/')[-1]

    def download_from_url(url):
        # NOTE the stream=True parameter below
        last_updated = time.time()
        logger.info(f"About to download from {url}")
        with requests.get(url, stream=True, proxies={"http": "", "https": ""}) as resp:
            logger.info(f"Server Response Header: {resp.headers}")
            resp.raise_for_status()

            file_size = int(resp.headers['content-length'])
            read_size = 0

            last_updated = time.time()
            with open(dataset_file, 'wb') as data_fd:
                for chunk in resp.iter_content(chunk_size=chunk_size):
                    read_size += len(chunk)
                    data_fd.write(chunk)
                    current = time.time()
                    if (current - last_updated) > 1:
                        progress = round(min(read_size / file_size, 1) * 100, 2)
                        task.update(progress=progress)
                        last_updated = current
            task.update(name='下载完成，正在解压', status='inprogress', progress=100)
        result = extract(dataset_file.resolve().as_posix(), dataset_dir.resolve().as_posix())

        if result != 0:
            task.update(name='解压失败', status='error', progress=100, desc='数据解压失败，请确保上传的数据集是有效的 zip 或 tar.gz 压缩包')
        else:
            task.update(name='数据集已下载', status='success', progress=100)
        task.update(name='数据集已下载', status='success', progress=100)

    try:
        logger.info("Try to download from local cache")
        local_cache = f'http://{dataset["cache"][to_camel_case("yaan_1")]}/{dataset["path"]}'
        download_from_url(local_cache)
        logger.info('Downloaded from local cache successfully')
    except Exception as e:
        logger.exception(f'download from local error: {e}')
        url_aliyun = sign_rtmp_url(
            credentials['accessKeyId'],
            credentials['accessKeySecret'],
            credentials['securityToken'],
            dataset['domain'],
            dataset['path'],
            dataset['datasetCenter']['bucket']
        )
        download_from_url(url_aliyun)
    finally:
        task.done()


class DatasetDownloadHandler(FeaturizeHandler):

    async def post(self):
        data = self.get_json_body()
        logger.info(f"Dataset: {data['dataset']}, Credentials: {data['credentials']}")
        async_child_process(target=download_dataset_main, args=(data['dataset'], data['credentials']))
        self.write({})


class TerminateProcessHandler(FeaturizeHandler):

    def post(self):
        pid = self.params.get('pid')
        os.kill(pid, signal.SIGINT)


def compress_files(pwd, files):
    i = 0
    while True:
        if i == 0:
            output_file = "output.zip"
        else:
            output_file = f"output.{i}.zip"
        if not os.path.exists(os.path.join(pwd, output_file)):
            break
        i += 1

    task = Task(icon='folder', name='正在压缩文件', progress=0, status='inprogress', desc=f"压缩完成后会在相同目录下产生 {output_file} 文件")
    ret = os.system(f"cd {pwd} && zip -r {output_file} {' '.join(files)}")
    if ret == 0:
        task.update(name='压缩已完成', progress=100, status='success')
    else:
        task.update(name='压缩出现错误', progress=0, status='failed', desc="文件压缩失败，请尝试用命令行手动压缩")
    task.done()


def uncompress_file(pwd, file):
    task = Task(icon='folder', name='正在解压文件', progress=0, status='inprogress', desc=f"解压缩会覆盖所有重名文件")
    pwd = Path(pwd)
    tarball = Path(pwd) / file
    logger.info(tarball.resolve().as_posix())
    logger.info(pwd.resolve().as_posix())
    ret = extract(tarball.resolve().as_posix(), pwd.resolve().as_posix())
    if ret == 0:
        task.update(name='解压已完成', progress=100, status='success')
    else:
        task.update(name='解压出现错误', progress=0, status='failed', desc="文件解压失败，请尝试用命令行手动解压")
    task.done()


class RemoveFolderFilesHandler(FeaturizeHandler):

    def post(self):
        files = self.params.get('files')
        path = self.params.get('path')
        files = [file['name'] for file in files]
        command_pwd = os.path.join(_web_app.settings["server_root_dir"], path)
        for file in files:
            dest = os.path.join(command_pwd, file)
            if os.path.isdir(dest):
                shutil.rmtree(dest)
            else:
                os.remove(dest)
        self.write()


class CompressHandler(FeaturizeHandler):

    def post(self):
        files = self.params.get('files')
        path = self.params.get('path')
        files = [file['name'] for file in files]
        command_pwd = os.path.join(_web_app.settings["server_root_dir"], path)
        async_child_process(target=compress_files, args=(command_pwd, files))


class UncompressHandler(FeaturizeHandler):

    def post(self):
        file = self.params.get('file')['name']
        path = self.params.get('path')
        command_pwd = os.path.join(_web_app.settings["server_root_dir"], path)
        async_child_process(target=uncompress_file, args=(command_pwd, file))


class SshHandler(FeaturizeHandler):

    @property
    def keys_file(self):
        if hasattr(self, "_keys_file"):
            return self._keys_file
        ssh_dir = Path.home() / 'work' / '.ssh'
        ssh_dir.mkdir(parents=True, exist_ok=True)
        keys_file = ssh_dir / "authorized_keys"
        keys_file.touch()
        self._keys_file = keys_file
        return self._keys_file

    @property
    def existing_ssh_keys(self):
        if hasattr(self, "_existing_ssh_keys"):
            return self._existing_ssh_keys
        ssh_dir = Path.home() / 'work' / '.ssh'
        ssh_dir.mkdir(parents=True, exist_ok=True)
        ssh_keys = []
        try:
            keys_file = ssh_dir / "authorized_keys"
            with keys_file.open() as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        ssh = SSHKey(line, strict=True)
                    except:
                        continue
                    ssh_keys.append(ssh)
        except FileNotFoundError:
            pass

        self._existing_ssh_keys = [{
            'hash': key.hash_md5(),
            'comment': key.comment,
            'keydata': key.keydata
        } for key in ssh_keys]

        return self._existing_ssh_keys

    def persist(self, keys):
        self.keys_file.write_text("\n".join([key['keydata'] for key in keys]))

    async def get(self):
        self.write(self.existing_ssh_keys)

    def delete(self):
        keyhash = self.params.get("keyhash")
        keys = list(filter(lambda x: x['hash'] != keyhash, self.existing_ssh_keys))
        self.persist(keys)
        self.write()

    def post(self):
        new_sshkey = self.params.get("sshkey")
        sshkey = SSHKey(new_sshkey, strict=True)
        try:
            sshkey.parse()
        except:
            return self.write(code=9999, message="不是有效的公钥文本")

        # 检查哈希值，若有相同的hash值则不添加
        if any([x['hash'] == sshkey.hash_md5() for x in self.existing_ssh_keys]):
            return self.write()

        self.existing_ssh_keys.append({
            'hash': sshkey.hash_md5(),
            'comment': sshkey.comment,
            'keydata': sshkey.keydata
        })

        self.persist(self.existing_ssh_keys)
        self.write()


def setup_handlers(web_app):
    global websocket, pool, _web_app

    # keep inference
    _web_app = web_app

    base_url = web_app.settings["base_url"]

    featurize_handlers = [
        (f'{base_url}featurize/token', TokenHandler),
        (f'{base_url}featurize/busaddr', BusaddrHandler),
        (f'{base_url}featurize/datasets/download', DatasetDownloadHandler),
        (f'{base_url}featurize/ssh', SshHandler),
        (f'{base_url}featurize/terminate', TerminateProcessHandler),
        (f'{base_url}featurize/compress', CompressHandler),
        (f'{base_url}featurize/uncompress', UncompressHandler),
        (f'{base_url}featurize/remove_folder_files', RemoveFolderFilesHandler),
    ]
    web_app.add_handlers(".*", featurize_handlers)

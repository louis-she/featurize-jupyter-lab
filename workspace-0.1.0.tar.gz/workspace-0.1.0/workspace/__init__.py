from pathlib import Path
import os
import json
import tornado
from jupyter_server.auth.login import LoginHandler
from jupyter_server.auth.logout import LogoutHandler
from jupyterlab.labapp import LabApp

from ._version import __version__

HERE = Path(__file__).parent.resolve()

with (HERE / "labextension" / "package.json").open() as fid:
    data = json.load(fid)

def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": data["name"]
    }]



from .handlers import setup_handlers


def _jupyter_server_extension_points():
    return [{
        "module": "workspace"
    }]


def _load_jupyter_server_extension(server_app):
    """Registers the API handler to receive HTTP requests from the frontend extension.

    Parameters
    ----------
    server_app: jupyterlab.labapp.LabApp
        JupyterLab application instance
    """
    setup_handlers(server_app.web_app)

load_jupyter_server_extension = _load_jupyter_server_extension


class FeaturizeLoginHandler(LoginHandler):

    @staticmethod
    def login_available(settings):
        return True

    async def _user_bus_status(self):
        # get user status
        client = tornado.httpclient.AsyncHTTPClient()
        try:
            response = await client.fetch(
                f'{os.getenv("BUS_INNER_ADDR")}/bus/api/v1/user_status',
                headers={'cookie': self.request.headers.get('cookie', '')}
            )
        except tornado.httpclient.HTTPClientError:
            raise tornado.web.HTTPError(401)

        data = json.loads(response.body.decode())
        self.log.info(f'server user status response with: {data}')
        return data['data']

    async def get(self):
        if self.current_user:
            next_url = self.get_argument('next', default=self.base_url)
            return self.redirect(next_url)
        # 检查用户是否在 bus 中登录，如果有，set cookie 然后跳转到 next_url
        # 如果没有，跳转到 bus 的登录页面
        user_status = await self._user_bus_status()
        self.log.info(f'instance uuid: {os.getenv("UUID")}, user status: {user_status}, klass {user_status.__class__.__name__}')
        if user_status and user_status.get('user_id') is not None and os.getenv('UUID') in user_status['instance_ids']:
            self.log.info('validate passed. redirect to workspace')
            self.set_login_cookie(self, user_id=user_status['user_id'])
            self.redirect(f'{self.base_url}lab')
        else:
            self.log.info('validate failed. redirect to bus signin page')
            self.redirect(f'{os.getenv("BUS_ADDR")}/signin?next={os.getenv("LAB_ADDR")}{self.base_url}lab')


class FeaturizeLogoutHandler(LogoutHandler):
    pass
